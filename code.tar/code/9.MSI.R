rm(list=ls())
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
load('hypoxia.Rdata')
rownames(CESCfinalfpkm) <- CESCfinalfpkm[,1]
CESCfinalfpkm <- CESCfinalfpkm[,-1]
CESCexpr <- CESCfinalfpkm[,-c(1:11)]
CESCexpr[1:4,1:4]
CESCexpr <- as.data.frame(t(CESCexpr))
#write.csv(CESCexpr,file='CESCexpr.csv',row.names = T,col.names = T)
##参考必须转化成txt文件
path=c('D:/Tcell分型宫颈癌/CESCexpr.txt')
library(PreMSIm)
input_data=data_pre(path, type = "Symbol")##必须用wps做

MSI <- msi_pre(input_data)
identical(MSI$Sample,rownames(sample))
MSI_status <- MSI$MSI_status
MSIfinal <- cbind(sample,MSI)

save(MSIfinal,file = 'MSIfinal.Rdata')
rm(list=ls())
load('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/一、宫颈癌缺氧(聚类分析+基因组+免疫治疗组)/MSIfinal.Rdata')
##fisher精确性检验
##参考《Fisher's exact test( 费希尔精确检验) 以及R中的计算》
##https://www.jianshu.com/p/7b0231485d11
MSIyes <- subset(MSIfinal,MSI_status==1)
table(MSIyes$group)
#1  2 
#46 61
MSIok <- c(35,23,69)
MSIno <- subset(MSIfinal,MSI_status==0)
table(MSIno$group)
#1  2 
#46 61
MSInot <- c(77,37,75)

MSIfisher <- data.frame(MSIok,MSInot)
rownames(MSIfisher) <- c('L-hypoxia','H-hypoxia','M-hypoxia')

result <- fisher.test(MSIfisher)
result$p.value

##结果是肯定的

##可视化
MSIplot <- MSIfinal[,-2]
MSIplot$group <- factor(MSIplot$group,levels = c(1,2,3),labels = c('subtype1','subtype2','subtype3'))
MSIplot$MSI_status <- as.factor(MSIplot$MSI_status)

library(ggplot2)
library(tibble)
g <- ggplot(MSIplot,aes(x=group))
##用这个堆叠的
pval <- tibble(
  x=c(1.8,2.2),
  y=c(1.05,1.05)
)
g + geom_bar(aes(fill=MSI_status),position = 'fill',width = 0.5)+
  scale_fill_manual(values = c('#00CD66','#EEEE00'))+
  xlab('')+
  ylab('')+
  labs(title = 'MSI',fill='MSI status')+
  theme(plot.title = element_text(color = 'black',
                                  size=15,
                                  hjust=0.5))+
  theme_classic()+
  #annotate('text',x=2.0,y=1.5,label = '**',size=7)+
  scale_x_discrete(label=c('L-hypoxia','H-hypoxia','M-hypoxia'))+
  geom_signif(comparisons = list(c('L-hypoxia', 'H-hypoxia'),
                                 c('L-hypoxia','M-hypoxia'),
                                 c('H-hypoxia','M-hypoxia')),
              map_signif_level=T,
              textsize=4,test=chisq.test,step_increase=0.2)
##标题参数 参考https://www.cnblogs.com/jessepeng/p/12307803.html