rm(list = ls())
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
load('PC1score.Rdata')
CESCexpr <- CESCfinalfpkm[,-c(2:12)]
rownames(CESCexpr) <- CESCexpr[,1]
CESCexpr <- CESCexpr[,-1]
expr <- CESCexpr

Mscore <- median(hypoxiaScore$hypoxiaScore,na.rm = FALSE)
group <- as.vector(ifelse((hypoxiaScore$hypoxiaScore)>Mscore,"high","low"))
hypoxiaScoreall <- cbind(hypoxiaScore,group)
highscoresample <- rownames(subset(hypoxiaScoreall,group=='high'))
highscore <- expr[highscoresample,]
lowscoresample <- rownames(subset(hypoxiaScoreall,group=='low'))
lowscore <- expr[lowscoresample,]
##IC
inhibitor <- c('PDCD1','CTLA4','CD274','HAVCR2','LAG3','TIGIT')
highinhibitor <- highscore[,inhibitor]
lowinhibitor <- lowscore[,inhibitor]
inhibitor <- rbind(highinhibitor,lowinhibitor)
group <- c(rep('highscore',148),rep('lowscore',148))
inhibitor$group <- group
inhibitor$group = factor(inhibitor$group, levels=c('highscore','lowscore'))

pval <- c()
for(i in c(1:6)){
  p=wilcox.test(inhibitor[,i]~inhibitor$group)$p.value
  #存放p值
  pval=c(pval,p)
}
pval <- as.data.frame(pval)
rownames(pval) <- colnames(inhibitor)[1:6]
#替换成*号
pval$mark <- as.factor(ifelse(pval$pval > 0.05,'ns',
                              ifelse(pval$pval> 0.01,'*',
                                     ifelse(pval$pval>0.001,'**','***'))
))
pvalimmune <- pval


library(reshape2)
inhibitormelt <- melt(inhibitor,id.vars=c("group"),
                      measure.vars = colnames(inhibitor)[1:6],variable.name = "inhibitor",value.name = "expression")
ggplot(data = inhibitormelt, aes(x=inhibitor,y=expression))+
  geom_boxplot(aes(fill=group))+
  theme_bw()+
  theme(axis.text.x=element_text(vjust=1,size=10))+
  scale_fill_manual(values = c('highscore'='firebrick','lowscore'='darkblue'))+
  annotate('text',x='PDCD1',y=7.5,label = 'ns',size=5)+
  annotate('text',x='CTLA4',y=7.5,label = 'ns',size=5)+
  annotate('text',x='CD274',y=7.5,label = 'ns',size=5)+
  annotate('text',x='HAVCR2',y=7.5,label = 'ns',size=5)+
  annotate('text',x='LAG3',y=7.5,label = 'ns',size=5)+
  annotate('text',x='TIGIT',y=7.5,label = '*',size=5)+
  theme(axis.text.x = element_text(
    size = 10
  ))

##
ef <- c('GZMB','PRF1','TNF','IFNG','LAMP1')
firstef <- group1[,ef]
secondinhabitor <- group2[,ef]
thirdinhabitor <- group3[,ef]
ef <- rbind(firstef,secondinhabitor,thirdinhabitor)
group <- c(rep('L-hypoxia',112),rep('H-hypoxia',60),rep('M-hypoxia',124))
ef$group <- group
ef$group = factor(ef$group, levels=c('L-hypoxia','H-hypoxia','M-hypoxia'))

pval <- c()
for(i in c(1:5)){
  p=summary(aov(ef[,i]~ef$group))[[1]][1,5]
  #存放p值
  pval=c(pval,p)
}
pval <- as.data.frame(pval)
rownames(pval) <- colnames(ef)[1:5]
#替换成*号
pval$mark <- as.factor(ifelse(pval$pval > 0.05,'ns',
                              ifelse(pval$pval> 0.01,'*',
                                     ifelse(pval$pval>0.001,'**','***'))
))
pvalef <- pval


library(reshape2)
efmelt <- melt(ef,id.vars=c("group"),
               measure.vars = colnames(ef)[1:5],variable.name = "ef",value.name = "expression")
ggplot(data = efmelt, aes(x=ef,y=expression))+
  geom_boxplot(aes(fill=group))+
  theme_bw()+
  theme(axis.text.x=element_text(vjust=1,size=10))+
  scale_fill_manual(values = c('L-hypoxia'='#ff7f00','H-hypoxia'='#1f78b4','M-hypoxia'='#B03060'))+
  annotate('text',x='GZMB',y=16,label = '**',size=5)+
  annotate('text',x='PRF1',y=16,label = 'ns',size=5)+
  annotate('text',x='TNF',y=16,label = '***',size=5)+
  annotate('text',x='IFNG',y=16,label = '*',size=5)+
  annotate('text',x='LAMP1',y=16,label = '*',size=5)+
  theme(axis.text.x = element_text(
    size = 10
  ))
