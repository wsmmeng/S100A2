##宫颈癌
##参考周末教程代码 泛癌代码 《maftools|TCGA肿瘤突变数据的汇总，分析和可视化》
rm(list = ls())
load('hypoxia.Rdata')
require(maftools)
options(stringsAsFactors = F) 
library(data.table)
tmp=fread('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/一、宫颈癌缺氧(聚类分析+基因组+免疫治疗组)/TCGA-CESC.mutect2_snv.tsv.gz')
head(tmp)   
colnames(tmp) =c( "Tumor_Sample_Barcode", "Hugo_Symbol", 
                  "Chromosome", "Start_Position", 
                  "End_Position", "Reference_Allele", "Tumor_Seq_Allele2", 
                  "HGVSp_Short" , 'effect' ,"Consequence",
                  "vaf" ) 
tmp$Entrez_Gene_Id =1
tmp$Center ='ucsc'
tmp$NCBI_Build ='GRCh38'
tmp$NCBI_Build ='GRCh38'
tmp$Strand ='+'
tmp$Variant_Classification = tmp$effect
tail(sort(table(tmp$Variant_Classification )))
tmp$Tumor_Seq_Allele1 = tmp$Reference_Allele
tmp$Variant_Type = ifelse(
  tmp$Reference_Allele %in% c('A','C','T','G') & tmp$Tumor_Seq_Allele2 %in% c('A','C','T','G'),
  'SNP','INDEL'
)
tmp$Tumor_Sample_Barcode <- gsub('-','.',tmp$Tumor_Sample_Barcode)
##取cluster1中的样本
cluster1sample <- subset(sample,group==1)
ID1 <- rownames(cluster1sample)
library(dplyr)
cluster1 <- tmp %>% filter(Tumor_Sample_Barcode%in%ID1)
#cluster1 <- subset(tmp,( Tumor_Sample_Barcode %in% ID ))都是一样的
cluster1maf = read.maf(maf = cluster1,
                       vc_nonSyn=names(tail(sort(table(cluster1$Variant_Classification )))))


##取cluster2中的样本
cluster2sample <- subset(sample,group==2)
ID2 <- rownames(cluster2sample)
library(dplyr)
cluster2 <- tmp %>% filter(Tumor_Sample_Barcode%in%ID2)
#cluster1 <- subset(tmp,( Tumor_Sample_Barcode %in% ID ))都是一样的
cluster2maf = read.maf(maf = cluster2,
                       vc_nonSyn=names(tail(sort(table(cluster2$Variant_Classification )))))

##取cluster3中的样本
cluster3sample <- subset(sample,group==3)
ID3 <- rownames(cluster3sample)
library(dplyr)
cluster3 <- tmp %>% filter(Tumor_Sample_Barcode%in%ID3)
#cluster1 <- subset(tmp,( Tumor_Sample_Barcode %in% ID ))都是一样的
cluster3maf = read.maf(maf = cluster3,
                       vc_nonSyn=names(tail(sort(table(cluster3$Variant_Classification )))))

##cluster1
##经典瀑布图
pdf(file="cluster1CESC.pdf",width=10,height=8)
oncoplot(maf = cluster1maf,top = 20)
dev.off()
##选取关注基因 ref:http://life.smxz.com.cn/Content/index/pid/73/aid/4527.html
oncostrip(maf = cluster1maf, genes = c('PIK3CA','PTEN','TP53','KRAS'))
##
##plot titv summary
laml.titv = titv(maf = cluster1maf, plot = FALSE, useSyn = TRUE)
pdf(file="cluster1titv.pdf",width=8,height=3)
plotTiTv(res = laml.titv)
dev.off()

##cluster2
##经典瀑布图
pdf(file="cluster2CESC.pdf",width=10,height=8)
oncoplot(maf = cluster2maf,top = 20)
dev.off()
##选取关注基因
oncostrip(maf = cluster2maf, genes = c('PIK3CA','PTEN','TP53','KRAS'))
##plot titv summary

laml.titv = titv(maf = cluster2maf, plot = FALSE, useSyn = TRUE)

pdf(file="cluster2titv.pdf",width=8,height=3)
plotTiTv(res = laml.titv)
dev.off()
##cluster3
##经典瀑布图
pdf(file="cluster3CESC.pdf",width=10,height=8)
oncoplot(maf = cluster3maf,top = 20)
dev.off()
##选取关注基因
oncostrip(maf = cluster3maf, genes = c('PIK3CA','PTEN','TP53','KRAS'))
##plot titv summary
pdf(file="cluster3titv.pdf",width=8,height=3)
plotTiTv(res = laml.titv)
dev.off()




##比较
#比较最少Mut个数为5的基因
pt.vs.rt <- mafCompare(m1 = cluster1maf, m2 = cluster2maf, m1Name = 'L-hypoxia', m2Name = 'H-hypoxia', minMut = 5)
print(pt.vs.rt)
forestPlot(mafCompareRes = pt.vs.rt, pVal = 0.01, color = c('royalblue', 'maroon'), geneFontSize = 0.8)

pt.vs.rt <- mafCompare(m1 = cluster3maf, m2 = cluster2maf, m1Name = 'M-hypoxia', m2Name = 'H-hypoxia', minMut = 5)
print(pt.vs.rt)
forestPlot(mafCompareRes = pt.vs.rt, pVal = 0.01, color = c('royalblue', 'maroon'), geneFontSize = 0.8)

pt.vs.rt <- mafCompare(m1 = cluster1maf, m2 = cluster3maf, m1Name = 'L-hypoxia', m2Name = 'M-hypoxia', minMut = 5)
print(pt.vs.rt)
forestPlot(mafCompareRes = pt.vs.rt, pVal = 0.01, color = c('royalblue', 'maroon'), geneFontSize = 0.8)
