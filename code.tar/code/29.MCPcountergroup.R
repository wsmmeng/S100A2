rm(list = ls())

load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
load('PC1score.Rdata')
CESCexpr <- CESCfinalfpkm[,-c(2:12)]
rownames(CESCexpr) <- CESCexpr[,1]
CESCexpr <- CESCexpr[,-1]
expr <- CESCexpr

Mscore <- median(hypoxiaScore$hypoxiaScore,na.rm = FALSE)
group <- as.vector(ifelse((hypoxiaScore$hypoxiaScore)>Mscore,"high","low"))
hypoxiaScoreall <- cbind(hypoxiaScore,group)
highscoresample <- rownames(subset(hypoxiaScoreall,group=='high'))
highscore <- expr[highscoresample,]
lowscoresample <- rownames(subset(hypoxiaScoreall,group=='low'))
lowscore <- expr[lowscoresample,]

highscore <- as.data.frame(t(highscore))
lowscore <- as.data.frame(t(lowscore))

##第二步 进行分析
##高风险组进行分析
library(curl)
library(MCPcounter)
options(timeout= 4000000)
MCPcounterhighscore <- MCPcounter.estimate(
  highscore,
  featuresType=c('HUGO_symbols')[1],          
  probesets=read.table(curl('http://raw.githubusercontent.com/ebecht/MCPcounter/master/Signatures/probesets.txt'),sep='\t',stringsAsFactors=FALSE,colClasses='character'),
  genes=read.table(curl('http://raw.githubusercontent.com/ebecht/MCPcounter/master/Signatures/genes.txt'),sep='\t',stringsAsFactors=FALSE,header=TRUE,colClasses='character',check.names=FALSE)
)
MCPcounterhighscore <- as.data.frame(t(MCPcounterhighscore))

MCPcounterlowscore <- MCPcounter.estimate(
  lowscore,
  featuresType=c('HUGO_symbols')[1],          
  probesets=read.table(curl('http://raw.githubusercontent.com/ebecht/MCPcounter/master/Signatures/probesets.txt'),sep='\t',stringsAsFactors=FALSE,colClasses='character'),
  genes=read.table(curl('http://raw.githubusercontent.com/ebecht/MCPcounter/master/Signatures/genes.txt'),sep='\t',stringsAsFactors=FALSE,header=TRUE,colClasses='character',check.names=FALSE)
)
MCPcounterlowscore<- as.data.frame(t(MCPcounterlowscore))


save(MCPcounterhighscore,MCPcounterlowscore,file='MCP.Rdata')
