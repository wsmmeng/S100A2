rm(list=ls())
load('estimatesubtype1.Rdata')
load('estimatesubtype2.Rdata')
load('estimatesubtype3.Rdata')
estimate <- rbind(subtype1score,subtype2score,subtype3score)



estimate$subtype <- c(rep('L-hypoxia',112),
                      rep('H-hypoxia',60),
                      rep('M-hypoxia',124))
estimate$subtype <- factor(estimate$subtype,levels = c('L-hypoxia','H-hypoxia','M-hypoxia'))
kruskal.test(estimate$ImmuneScore~estimate$subtype,data=estimate)#无差异
kruskal.test(estimate$ESTIMATEScore~estimate$subtype,data=estimate)#有差异
kruskal.test(estimate$StromalScore~estimate$subtype,data=estimate)#有差异

library(ggplot2)
library(pacman)
pacman::p_load(tidyverse,ggpubr,rstatix,ggsci,ggsignif,reshape2)
ggplot(estimate,aes(subtype,StromalScore,fill=subtype)) + 
  geom_violin()+
  geom_boxplot(width = 0.2,fill='white') +
  theme_bw()+
  #scale_fill_jco()+
  #geom_jitter(shape=16,size=2,position=position_jitter(0.2))+
  geom_signif(comparisons = list(c('L-hypoxia', 'H-hypoxia'),
                                 c('L-hypoxia','M-hypoxia'),
                                 c('H-hypoxia','M-hypoxia')),
              map_signif_level=T,
              textsize=4,test=t.test,step_increase=0.2)+
  guides(fill=F)+xlab(NULL)+
  scale_fill_manual(values = c('L-hypoxia'='#ff7f00','H-hypoxia'='#1f78b4','M-hypoxia'='#B03060'))


ggplot(estimate,aes(subtype,ImmuneScore,fill=subtype)) + 
  geom_violin()+
  geom_boxplot(width = 0.2,fill='white') +
  theme_bw()+
  #scale_fill_jco()+
  #geom_jitter(shape=16,size=2,position=position_jitter(0.2))+
  geom_signif(comparisons = list(c('L-hypoxia', 'H-hypoxia'),
                                 c('L-hypoxia','M-hypoxia'),
                                 c('H-hypoxia','M-hypoxia')),
              map_signif_level=T,
              textsize=4,test=t.test,step_increase=0.2)+
  guides(fill=F)+xlab(NULL)+
  scale_fill_manual(values = c('L-hypoxia'='#ff7f00','H-hypoxia'='#1f78b4','M-hypoxia'='#B03060'))

ggplot(estimate,aes(subtype,ESTIMATEScore,fill=subtype)) + 
  geom_violin()+
  geom_boxplot(width = 0.2,fill='white') +
  theme_bw()+
  #scale_fill_jco()+
  #geom_jitter(shape=16,size=2,position=position_jitter(0.2))+
  geom_signif(comparisons = list(c('L-hypoxia', 'H-hypoxia'),
                                 c('L-hypoxia','M-hypoxia'),
                                 c('H-hypoxia','M-hypoxia')),
              map_signif_level=T,
              textsize=4,test=t.test,step_increase=0.2)+
  guides(fill=F)+xlab(NULL)+
  scale_fill_manual(values = c('L-hypoxia'='#ff7f00','H-hypoxia'='#1f78b4','M-hypoxia'='#B03060'))
