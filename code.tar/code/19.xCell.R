rm(list=ls())
##数据准备：ESTIMATE用count值
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
load('hypoxia.Rdata')
CESCexpr <- CESCfinalfpkm[,-c(2:12)]
rownames(CESCexpr) <- CESCexpr[,1]
CESCexpr <- CESCexpr[,-1]
expr <- CESCexpr
#colnames(OVfinal)[1:10]
subtype1 <- subset(sample,group==1)
subtype1name <- rownames(subtype1)
subtype1 <- expr[subtype1name,] 
subtype2 <- subset(sample,group==2)
subtype2name <- rownames(subtype2)
subtype2<- expr[subtype2name,] 
subtype3 <- subset(sample,group==3)
subtype3name <- rownames(subtype3)
subtype3<- expr[subtype3name,] 
subtype1 <- as.data.frame(t(subtype1))
subtype2 <- as.data.frame(t(subtype2))
subtype3 <- as.data.frame(t(subtype3))


library(xCell)
##如果是芯片数据
#xCell<- xCellAnalysis(highrisk)
#xCell <- t(xCell)
#xCell <- as.data.frame(xCell)
#write.csv(xCell,file = 'xCellhighrisk.csv')
## 如果是RNA-seq数据，则
xCellsubtype1<- xCellAnalysis(subtype1,rnaseq = T)
xCellsubtype1 <- as.data.frame(t(xCellsubtype1))

xCellsubtype2<- xCellAnalysis(subtype2,rnaseq = T)
xCellsubtype2<- as.data.frame(t(xCellsubtype2))

xCellsubtype3<- xCellAnalysis(subtype3,rnaseq = T)
xCellsubtype3<- as.data.frame(t(xCellsubtype3))
save(xCellsubtype1,xCellsubtype2,xCellsubtype3,file='xcell.Rdata')
