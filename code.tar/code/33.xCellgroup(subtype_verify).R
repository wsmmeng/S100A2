rm(list=ls())
load('xcellgroup.Rdata')
group <- c(rep('highscore',148),rep('lowscore',148))
xcell <- rbind(xCellhighscore,xCelllowscore)
xcellall <- cbind(group,xcell)

celltype <- c("iDC","aDC","cDC","Th2 cells","Th1 cells","CD4+ Tem","CD8+ naive T-cells","Macrophages M2",
              "Monocytes","Tgd cells")
celltypeexpr <- xcellall[,c('group',celltype)]
celltypeexpr$group <- factor(celltypeexpr$group,levels = c('highscore','lowscore'))
library(reshape2)
celltypemelt <- melt(celltypeexpr,id.vars=c("group"),
                     measure.vars = colnames(celltypeexpr)[2:11],variable.name = "celltype",value.name = "expression")

ggplot(data = celltypemelt, aes(x=celltype,y=expression,color=group))+
  geom_boxplot(aes(color=group))+
  theme(axis.text.x=element_text(vjust=1,size=10))+
  theme_classic()+
  scale_color_manual(values = c('highscore'='firebrick','lowscore'='darkblue'))+
  annotate('text',x='iDC',y=1,label = '*',size=5)+
  annotate('text',x='aDC',y=1,label = '*',size=5)+
  annotate('text',x='cDC',y=1,label ='***',size=5)+
  annotate('text',x='Th2 cells',y=1,label = '***',size=5)+
  annotate('text',x='Th1 cells',y=1,label = '***',size=5)+
  annotate('text',x='CD4+ Tem',y=1,label = '**',size=5)+
  annotate('text',x='CD8+ naive T-cells',y=1,label = 'ns',size=5)+
  annotate('text',x='Macrophages M2',y=1,label = 'ns',size=5)+
  annotate('text',x='Monocytes',y=1,label = '***',size=5)+
  annotate('text',x='Tgd cells',y=1,label = '***',size=5)+
  labs(title = 'xCell',x='celltype',y='score')+
  theme(axis.text.x = element_text(
    angle = 45,
    hjust = 1,
    vjust = 1
  ))+
  ylim(0,1)
 
