##参考《maftools包计算TMB值》https://www.jianshu.com/p/664242ddf988
##宫颈癌
rm(list = ls())
load('hypoxia.Rdata')
require(maftools)
options(stringsAsFactors = F) 
library(data.table)
tmp2=fread('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/一、宫颈癌缺氧(聚类分析+基因组+免疫治疗组)/TCGA-CESC.mutect2_snv.tsv.gz')
head(tmp2)   
colnames(tmp2) =c( "Tumor_Sample_Barcode", "Hugo_Symbol", 
                   "Chromosome", "Start_Position", 
                   "End_Position", "Reference_Allele", "Tumor_Seq_Allele2", 
                   "HGVSp_Short" , 'effect' ,"Consequence",
                   "vaf" ) 
tmp2$Entrez_Gene_Id =1
tmp2$Center ='ucsc'
tmp2$NCBI_Build ='GRCh38'
tmp2$NCBI_Build ='GRCh38'
tmp2$Strand ='+'
tmp2$Variant_Classification = tmp2$effect
tail(sort(table(tmp2$Variant_Classification )))
tmp2$Tumor_Seq_Allele1 = tmp2$Reference_Allele
tmp2$Variant_Type = ifelse(
  tmp2$Reference_Allele %in% c('A','C','T','G') & tmp2$Tumor_Seq_Allele2 %in% c('A','C','T','G'),
  'SNP','INDEL'
)
table(tmp2$Variant_Type )





laml <- read.maf(maf = tmp2, vc_nonSyn=names(tail(sort(table(tmp2$Variant_Classification )))))
# laml = read.maf("TCGA.STAD.mutect.somatic.maf",clinicalData = 'clinical2.tsv',isTCGA = T)
## -Reading
## -Validating
## -Silent variants: 24377 
## -Summarizing
## --Mutiple centers found
## BI;WUGSC;BI;WUGSC--Possible FLAGS among top ten genes:
##   TTN
##   MUC16
##   FLG
##   SYNE1
##   HMCN1
##   USH2A
## -Processing clinical data
## --Missing clinical data
## -Finished in 6.864s elapsed (22.4s cpu)
x = tmb(maf = laml)
##x第三列就是TMB值了

TMBscore <- x[,c(1,3)]
score <- TMBscore[,2]
score <- as.data.frame(score)
samplename <- gsub('-','.',TMBscore$Tumor_Sample_Barcode)
rownames(score) <- samplename

scorecluster <- merge(sample,score,by=0,all=F)
rownames(scorecluster) <- scorecluster[,1]
scorecluster <- scorecluster[,-1]

shapiro.test(scorecluster$total_perMB)##方差不齐
bartlett.test(scorecluster$total_perMB~scorecluster$group,data=scorecluster)#不服从正态性分布
#三组之间不服从正太分布
#用Kruskal-Wallis检验 参考《R语言统计—Kruskal-Wallis检验》
kruskal.test(scorecluster$total_perMB~scorecluster$group,data=scorecluster)

##结果可以

scorecluster$group <- factor(scorecluster$group,levels = c(1,2,3),labels = c('L-hypoxia','H-hypoxia','M-hypoxia'))
##可视化

library(ggplot2)
library(pacman)
pacman::p_load(tidyverse,ggpubr,rstatix,ggsci,ggsignif,reshape2)
scorecluster<-subset(scorecluster, scorecluster$total_perMB < 15)##去掉极端值
{g <- ggplot(scorecluster,aes(x=group))
  g + geom_bar()
  g + geom_bar(aes(weight = total_perMB))
  g + geom_bar() + coord_flip()##翻转坐标轴
  
  g <- ggplot(scorecluster,aes(x=group,y=total_perMB)) 
  g + geom_col()
  
  pval <- tibble(
    x=c(1.8,2.2),
    y=c(760,760)
  )
  library(ggplot2)
  library(pacman)
  pacman::p_load(tidyverse,ggpubr,rstatix,ggsci,ggsignif,reshape2)
  g + geom_boxplot(aes(fill=group),width = 0.7) + 
    scale_fill_manual(values = c('#ff7f00','#1f78b4','#B03060'))+
    xlab('')+
    ylab('')+
    labs(title = 'TMB',fill='')+
    theme(plot.title = element_text(color = 'black',
                                    size=15,
                                    hjust=0.5))+
    #annotate('text',x=2.0,y=1,label = '**',size=7)+
    theme_classic()+
    scale_x_discrete(label=c('L-hypoxia','H-hypoxia','M-hypoxia'))+
    guides(fill='none')+
    geom_signif(comparisons = list(c('L-hypoxia', 'H-hypoxia'),
                                   c('L-hypoxia','M-hypoxia'),
                                   c('H-hypoxia','M-hypoxia')),
                map_signif_level=T,
                textsize=4,test=t.test,step_increase=0.2)
    
    
}  
##色系

