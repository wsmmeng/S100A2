library(ggplot2)
load('hallEs.Rdata')
load('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/一、宫颈癌缺氧(聚类分析+基因组+免疫治疗组)/hypoxia.Rdata')
hall <- as.data.frame(t(hallEs))
hall$subtype <- group
hall$subtype <- factor(hall$subtype,levels = c(1,2,3),labels = c('L-hypoxia','H-hypoxia','M-hypoxia'))
g <- ggplot(hall,aes(x=subtype,y=HALLMARK_HYPOXIA))

g + geom_boxplot(aes(fill=subtype),width = 0.7) + 
  scale_fill_manual(values = c('#ff7f00','#1f78b4','#B03060'))+
  xlab('')+
  ylab('Enrichment Score')+
  labs(title = 'Hypoxia Enrichment')+
  theme(plot.title = element_text(color = 'black',
                                  size=15,
                                  hjust=0.5))+
  #geom_line(data=pval,aes(x=x,y=y,subtype=1))+#
  annotate('text',x=2,y=0.97,label = '***',size=7)+
  guides(fill='none')+
  theme_classic()
