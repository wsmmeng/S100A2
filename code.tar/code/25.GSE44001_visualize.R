
rm(list = ls())
load('PC1score.Rdata')
load('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/五、宫颈癌缺氧(验证组GEO+其他妇科肿瘤)/GSE44001.Rdata')

eset <- expr44001
##取出基因的交集，避免有不在数据集中的基因
gene <- intersect(rownames(eset),rownames(rotation))
rotation2 <- rotation[gene,]
eset2 <- eset[gene,]

##merge调整行名的位置
mergeeset <- merge(rotation2,eset2,by=0,all=F)
rownames(mergeeset) <- mergeeset[,1]
mergeeset <- mergeeset[,-1]

rotation3 <- as.matrix(mergeeset[,c(1:296)])
eset3 <- as.matrix(mergeeset[,-c(1:296)])
hypoxias <- rotation3[,1]
hypoxiaeset <- as.data.frame(hypoxias)

##重复data.frame的值
library(dplyr)
hypoxiaesetall <- bind_cols(replicate(300, hypoxiaeset, simplify = FALSE))
hypoxiaesetall <- as.matrix(hypoxiaesetall)
##重复操作 参考https://bbs.pinggu.org/forum.php?mod=viewthread&tid=6265603&pid=49774205&page=1

##这个地方要把矩阵的名字去掉
names(eset3)<- NULL
names(hypoxiaesetall) <- NULL

##eset3必须要转置，参考《菜鸡的R语言学习笔记——数据结构 Part 3》
eset3 <- t(eset3)
eset4 <- eset3 %*% hypoxiaesetall

##这样就得到了score
score <- eset4[,1]
GSE44001setscore <- data.frame(score)

##临床信息与score merge起来

final <- merge(clinical,GSE44001setscore,by=0,all=F)
rownames(final) <- final[,1]
final <- final[,-1]
final <- na.omit(final)
save(final,file='GSE44001result.Rdata')

load(file='GSE44001result.Rdata')

##画KM曲线
##KM生存曲线
library(survminer) # 加载包
library(survival) # 加载包

##对score画生存曲线
Mscore <- median(final$score,na.rm = FALSE)
group <- as.vector(ifelse((final$score)>Mscore,"high","low"))
finalall <- cbind(final,group)
fit <- survfit(Surv(dfs.time,dfs.status) ~ group,  # 创建生存对象 
               data = finalall) # 数据集来源
ggsurvplot(fit,pval = TRUE,title='                              hypoxiaScore',
           conf.int = TRUE,
           xlab = "Follow up time(m)",
           ylab = "recurrent probability",
           surv.median.line = "hv",
           palette = "lancet",
           risk.table = T)

##确实是有差异的
