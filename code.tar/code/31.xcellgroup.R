rm(list = ls())
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
load('PC1score.Rdata')
CESCexpr <- CESCfinalfpkm[,-c(2:12)]
rownames(CESCexpr) <- CESCexpr[,1]
CESCexpr <- CESCexpr[,-1]
expr <- CESCexpr

Mscore <- median(hypoxiaScore$hypoxiaScore,na.rm = FALSE)
group <- as.vector(ifelse((hypoxiaScore$hypoxiaScore)>Mscore,"high","low"))
hypoxiaScoreall <- cbind(hypoxiaScore,group)
highscoresample <- rownames(subset(hypoxiaScoreall,group=='high'))
highscore <- expr[highscoresample,]
lowscoresample <- rownames(subset(hypoxiaScoreall,group=='low'))
lowscore <- expr[lowscoresample,]

highscore <- as.data.frame(t(highscore))
lowscore <- as.data.frame(t(lowscore))

library(xCell)
##如果是芯片数据
#xCell<- xCellAnalysis(highrisk)
#xCell <- t(xCell)
#xCell <- as.data.frame(xCell)
#write.csv(xCell,file = 'xCellhighrisk.csv')
## 如果是RNA-seq数据，则
xCellhighscore<- xCellAnalysis(highscore,rnaseq = T)
xCellhighscore <- as.data.frame(t(xCellhighscore))

xCelllowscore<- xCellAnalysis(lowscore,rnaseq = T)
xCelllowscore<- as.data.frame(t(xCelllowscore))


save(xCellhighscore,xCelllowscore,file='xcellgroup.Rdata')
