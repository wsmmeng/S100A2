load('deghypoxia.Rdata')
load('hypoxia.Rdata')
colnames(sampledeg) <- 'degcluster'
sampledeg$degcluster <- factor(sampledeg$degcluster,levels = c(1,2,3),labels = c('subtype1','subtype2','subtype3') )
colnames(sample) <- 'hypoxiacluster'
sample$hypoxiacluster <- factor(sample$hypoxiacluster,levels = c(1,2,3),labels = c('subtype1','subtype2','subtype3') )
sangkey <- cbind(sample,sampledeg)
sangkey$value <- runif(296, 1, 10)
library(ggplot2)
library(ggalluvial)
ggplot(sangkey,aes(y=value,axis2=hypoxiacluster,axis1=degcluster))+ #控制图形绘制
  geom_alluvium(aes(fill=degcluster),width=0,reverse=F,size=4,discern=T)+ #控制线条流向
  geom_stratum(width = 1/8, reverse = FALSE,discern = TRUE)+ #控制中间框的宽度
  geom_text(stat = "stratum", aes(label = after_stat(stratum)),reverse = FALSE, size = 4,angle=0,discern = TRUE)+ #控制中间的文字
  scale_x_continuous(breaks = 1:2,labels = c("Hypoxia-related genes", "DEG"))+
  theme_void()+#控制X轴上图标排序
  theme(legend.position = "right") #控制图例有无
dev.off()
