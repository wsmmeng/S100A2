DefaultAssay(CESC) <- "RNA"
#load('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/一、宫颈癌缺氧(聚类分析+基因组+免疫治疗组)/deg1c2.Rdata')
#load('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/一、宫颈癌缺氧(聚类分析+基因组+免疫治疗组)/deg2c3.Rdata')
load('deg1c2and3.Rdata')


##因为对比矩阵是subtype2对其他,所以上调的是铂耐药
degup <- subset(deg,g=='UP')
gene_symbol <- rownames(degup)

H_hypoxia_features <- list(gene_symbol)

H_hypoxiascore <- AddModuleScore(CESC,
                                 features = H_hypoxia_features,
                                 ctrl = 100,
                                 name = "H_hypoxia_Features")

colnames(H_hypoxiascore@meta.data)
colnames(H_hypoxiascore@meta.data)[14] <- "H_hypoxia_Score"

VlnPlot(H_hypoxiascore,features = "H_hypoxia_Score",pt.size = 0, adjust = 2,group.by = "celltype")
VlnPlot(H_hypoxiascore,features = "H_hypoxia_Score",pt.size = 0, adjust = 2,group.by = "seurat_clusters")

library(ggplot2)
mydata<- FetchData(H_hypoxiascore,vars = c("UMAP_1","UMAP_2","H_hypoxia_Score"))
a <- ggplot(mydata,aes(x = UMAP_1,y =UMAP_2,colour = H_hypoxia_Score))+
  geom_point(size = 1)+scale_color_gradientn(values = seq(0,1,0.2),
                                             colours = c('#333366',"#6666FF",'#CC3333','#FFCC33'))
a+ theme_bw() + theme(panel.grid.major = element_blank(),
                      panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"),
                      panel.border = element_rect(fill=NA,color="black", size=1, linetype="solid"))