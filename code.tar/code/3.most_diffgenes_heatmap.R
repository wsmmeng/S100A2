rm(list=ls())
load('hypoxia.Rdata')
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
rownames(CESCfinalfpkm) <- CESCfinalfpkm[,1]
CESCfinalfpkm <- CESCfinalfpkm[,-1]
CESCclinical <- CESCfinalfpkm[,c(1,2)]
CESCexpr <- CESCfinalfpkm[,-c(1:11)]
CESCexpr[1:4,1:4]
CESCexpr <- as.data.frame(t(CESCexpr))
load('setgene.Rdata')

##分亚型

sample$subtype <- factor(sample$group,levels = c(1,2,3),labels = c('L-hypoxia','H-hypoxia','L-hypoxia'))
sample <- sample[order(sample$group),]

geneexpr <- as.data.frame(t(setgenexpr))
identical(rownames(sample),rownames(geneexpr))
geneexpr <- geneexpr[rownames(sample),]##为了方便后续注释

geneexpr$subtype <- sample$subtype##这个时候geneexpr是按照亚型排列

##筛选一下变化最大的基因
pval=c()
#观察数据结构
for(i in c(1:182)){
  #根据type来将样本分成两组
  p=summary(aov(geneexpr[,i]~geneexpr$subtype))[[1]][1,5]
  #存放p值
  pval=c(pval,p)
}
pval <- data.frame(pval)
rownames(pval) <- colnames(geneexpr[,c(1:182)])
pval$sig <- as.factor(ifelse(pval$pval > 0.05,'ns',
                             ifelse(pval$pval > 0.01,'*',
                                    ifelse(pval$pval>0.001,'**','***'))
))
#var <- subset(pval,!sig=='ns')
var <- subset(pval,sig=='***')

##画热图
 ##先画基因表达量
vargene <- rownames(var)
vargeneexpr <- geneexpr[,vargene]
vargeneexpr <- as.data.frame(t(vargeneexpr))

exp <- apply(vargeneexpr, 1, scale)
rownames(exp) <- colnames(vargeneexpr)
exp <- t(exp)##列名是按照亚型排列的
##先做注释
sample$name <- rownames(sample)
sample <- sample[order(sample$group),]
annotation_col <- sample$group
annotation_col <- data.frame(annotation_col)
colnames(annotation_col) <- 'subtype'
rownames(annotation_col) <- sample$name
annotation_col$subtype <- factor(annotation_col$subtype,levels=c(1,2,3),labels=c('subtype1','subtype2','subtype3'))

library(ComplexHeatmap)
library(circlize)
colume_ha <- HeatmapAnnotation(
  df=annotation_col,
  col=list(
    subtype=c('subtype1'='#ff7f00','subtype2'='#1f78b4','subtype3'='#B03060')
  )
)
Heatmap(exp,
        name = 'Hierarchical clustering',
        cluster_rows = T,
        cluster_columns = F,
        show_column_names = F,
        show_row_names = F,
        top_annotation=colume_ha
        
)
