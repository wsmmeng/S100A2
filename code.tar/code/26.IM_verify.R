rm(list=ls())
load('PC1score.Rdata')
load('D:/泛癌免疫浸润(里面有处理突变信息和cluster分组免疫也很规范)/免疫浸润分析/免疫治疗数据集/IMvigor210.Rdata')

##取出基因的交集，避免有不在数据集中的基因
gene <- intersect(rownames(eset),rownames(rotation))
rotation2 <- rotation[gene,]
eset2 <- eset[gene,]

##merge调整行名的位置
mergeeset <- merge(rotation2,eset2,by=0,all=F)
rownames(mergeeset) <- mergeeset[,1]
mergeeset <- mergeeset[,-1]


rotation3 <- as.matrix(mergeeset[,c(1:296)])
eset3 <- as.matrix(mergeeset[,-c(1:296)])
hypoxias <- rotation3[,1]
hypoxiaeset <- as.data.frame(hypoxias)

##重复data.frame的值
library(dplyr)
hypoxiaesetall <- bind_cols(replicate(348, hypoxiaeset, simplify = FALSE))
hypoxiaesetall <- as.matrix(hypoxiaesetall)
##重复操作 参考https://bbs.pinggu.org/forum.php?mod=viewthread&tid=6265603&pid=49774205&page=1

##这个地方要把矩阵的名字去掉
names(eset3)<- NULL
names(hypoxiaesetall) <- NULL

##eset3必须要转置，参考《菜鸡的R语言学习笔记——数据结构 Part 3》
eset3 <- t(eset3)
eset4 <- eset3 %*% hypoxiaesetall

##这样就得到了score
score <- eset4[,1]
immunesetscore <- data.frame(score)

##临床信息与score merge起来
clinical <- pdata[,c(1,2,5,6)]
rownames(clinical) <- clinical[,1]
res <- clinical[,-1]
res <- data.frame(res)
rownames(res) <- rownames(clinical)
final <- merge(res,immunesetscore,by=0,all=F)
rownames(final) <- final[,1]
final <- final[,-1]
save(final,file='IMV210result.Rdata')

load(file='IMV210result.Rdata')
##ROC曲线
#对模型画ROC曲线
library(pROC)  # 加载pROC包
library(ggplot2)  # 调用ggplot2包以利用ggroc函数
roc1 <- roc(final$BOR_binary,final$score)
#建立曲线
auc(roc1)
ci(roc1)
##画图
##画一条曲线
plot(roc1,
     print.auc=TRUE, print.auc.x=0.4, print.auc.y=0.3,print.auc.cex=1.0,
     
     # 图像上输出AUC值,坐标为（x，y）
     auc.polygon=T, auc.polygon.col="#00F5FF", # 设置ROC曲线下填充色
     max.auc.polygon=F,  # 是否填充整个图像
     grid = F,#是否画网格线，如果是设置更多参数
     
     print.thres=F, print.thres.cex=0.6,## 图像上输出最佳截断值，字体缩放倍数
     smooth=T, # 绘制不平滑曲线
     main="IMvigor210", # 添加标题
     col="#EE6363",  # 曲线颜色
)   # 使横轴从0到1，表示为1-特异度


##fisher检验
##对score画生存曲线
Mscore <- median(final$score,na.rm = FALSE)
group <- as.vector(ifelse((final$score)>Mscore,"high","low"))
finalall <- cbind(final,group)
fit <- survfit(Surv(time,status) ~ group,  # 创建生存对象 
               data = finalall) # 数据集来源
ggsurvplot(fit,pval = TRUE,title='                              hypoxiaScore',
           conf.int = TRUE,
           xlab = "Follow up time(m)",
           ylab = "recurrent probability",
           surv.median.line = "hv",
           palette = "npg",
           risk.table = T)
##fisher精确性检验
##参考《Fisher's exact test( 费希尔精确检验) 以及R中的计算》
##https://www.jianshu.com/p/7b0231485d11
high <- subset(finalall,group=="high")
table(high$BOR_binary)
#NR  R 
#44 105
high <- c(44,105)
low <- subset(finalall,group=="low")
table(low$BOR_binary)
#NR R 
#24 125
low <- c(24,125)

immunefisher <- data.frame(high,low)
rownames(immunefisher) <- c('R','NR')

result <- fisher.test(immunefisher)
result <- chisq.test(immunefisher)
result$p.value
##有差异的

##可视化
g <- ggplot(finalall,aes(x=group))
g + geom_bar()
g + geom_bar(aes(fill=BOR_binary))

##用这个堆叠的
pval <- tibble(
  x=c(1.4,1.6),
  y=c(1,1)
)
g + geom_bar(aes(fill=BOR_binary),position = 'fill',width = 0.5)+
  scale_fill_manual(values = c('#00CD66','#EEEE00'))+
  xlab('hypoxiaScore')+
  ylab('')+
  labs(title = 'IMvigor210',fill='')+
  theme(plot.title = element_text(color = 'black',
                                  size=15,
                                  hjust=0.5))+
  scale_fill_manual(values = c('lightblue','red'))+
  annotate('text',x=1.5,y=1.01,label = '**',size=7)+
  theme_classic()+
  scale_x_discrete(labels=c('highscore','lowscore'))
##标题参数 参考https://www.cnblogs.com/jessepeng/p/12307803.html

g + geom_bar(aes(fill=res),position = position_dodge2(preserve = 'single'))+
  scale_fill_manual(values = c('#FF6A6A','#00BFFF'))
