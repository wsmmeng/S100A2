rm(list = ls())
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
load('PC1score.Rdata')
CESCexpr <- CESCfinalfpkm[,-c(2:12)]
rownames(CESCexpr) <- CESCexpr[,1]
CESCexpr <- CESCexpr[,-1]
expr <- CESCexpr

Mscore <- median(hypoxiaScore$hypoxiaScore,na.rm = FALSE)
group <- as.vector(ifelse((hypoxiaScore$hypoxiaScore)>Mscore,"high","low"))
hypoxiaScoreall <- cbind(hypoxiaScore,group)
highscoresample <- rownames(subset(hypoxiaScoreall,group=='high'))
highscore <- expr[highscoresample,]
lowscoresample <- rownames(subset(hypoxiaScoreall,group=='low'))
lowscore <- expr[lowscoresample,]
##IC
##IC
highS100A2 <- highscore[,c('S100A2')]
lowS100A2 <- lowscore[,c('S100A2')]
S100A2 <- c(highS100A2,lowS100A2)
group <- c(rep('highscore',148),rep('lowscore',148))
S100A2 <- data.frame(S100A2)
S100A2$group <- group
S100A2$group = factor(S100A2$group, levels=c('highscore','lowscore'))

wilcox.test(S100A2[,1]~S100A2[,2])

ggplot(data = S100A2, aes(x=group,y=S100A2))+
  geom_boxplot(aes(fill=group))+
  theme_bw()+
  theme(axis.text.x=element_text(vjust=1,size=10))+
  scale_fill_manual(values = c('highscore'='firebrick','lowscore'='darkblue'))+
  theme(axis.text.x = element_text(
    size = 10
  ))+
  geom_signif(comparisons = list(c('highscore', 'lowscore')
                                 ),
              map_signif_level=T,
              textsize=4,test=wilcox.test,step_increase=0.2)

