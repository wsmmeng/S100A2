rm(list = ls())
##cancersubtype聚类聚成3类还是比较科学
library(CancerSubtypes)
load('setgene.Rdata')
setgenexpr <- as.matrix(setgenexpr)
####check distribution
data.checkDistribution(setgenexpr)
###Feature selection by most variance
setgenexpr_F=FSbyVar(setgenexpr, cut.type = "topk",4000)
#index7=match(rownames(GBM_mRNA_Tumor1),rownames(GBM_mRNA_Normal))
#GBM_mRNA_Normal1=GBM_mRNA_Normal[index7,]
##data normalization
setgenexpr_norm=data.normalization(setgenexpr)

###！注意再这中间运用要计算一个K值，也就是cluster的个数,但我算出来是2,帮助文档是3
library(factoextra)
#前面已经标准化了，如果没有标准化要标准化
tumor <- as.data.frame(t(setgenexpr_norm))
library(factoextra)
fviz_nbclust(tumor, kmeans, method = "silhouette")
km.res <- kmeans(tumor,2)
fviz_cluster(km.res, data = tumor,labelsize = 1)
###！

######Concensus clustering
result1=ExecuteCC(clusterNum=3,d=setgenexpr_norm,maxK=5,
                  clusterAlg="hc",distance="pearson",title="hypoxia")##注意必须是矩阵而不是数据框
group=result1$group
table(group)

###result validation and visualization
distanceMatrix=result1$distanceMatrix
p_value=survAnalysis(mainTitle="hypoxia",CESCclinical$OS.time,
                     CESCclinical$OS,group,
                     distanceMatrix=distanceMatrix,similarity=TRUE)
saveFigure(foldername="hypoxia",filename="hypoxia",image_width=7,
           image_height=7,image_res=600)
sample <- as.data.frame(result1[["group"]])
colnames(sample)='group'
save(result1,sample,group,file='hypoxia.Rdata')

