
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
rownames(CESCfinalfpkm) <- CESCfinalfpkm[,1]
CESCfinalfpkm <- CESCfinalfpkm[,-1]
CESCclinical <- CESCfinalfpkm[,c(1,2)]
CESCexpr <- CESCfinalfpkm[,-c(1:11)]
CESCexpr[1:4,1:4]
CESCexpr <- as.data.frame(t(CESCexpr))

marker<- read.csv('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/一、宫颈癌缺氧(聚类分析+基因组+免疫治疗组)/hypoxia.csv',header=T)
marker <- marker[,1]
#marker <- marker[!duplicated(marker$OXIDATIVE_PHOSPHORYLATION),]




ingene <- intersect(marker,colnames(CESCfinalfpkm))
nogene <- marker[-which(marker %in% ingene)]
nogene
marker <- marker[-which(nogene %in% marker)]
#marker[which(marker=='GSDME')]='DFNA5'
#marker[which(marker=='POLR1H')]='HTEX6'
#ingene <- intersect(marker,colnames(CESCfinalfpkm))
#nogene <- marker[-which(marker %in% ingene)]
#nogene
#marker <- marker[-which(marker %in% nogene)]
setgenexpr <- CESCexpr[marker,]
setgenexpr <- na.omit(setgenexpr)

set <- c(rep('hypoxia',191))
##ssGSEA分数计算
genemarker <- data.frame(marker,set)

list<- split(as.matrix(genemarker)[,1], genemarker[,2])
library(GSVA)
ssgsea.res<-gsva(as.matrix(CESCexpr),
                 list,
                 method = "ssgsea",
                 kcdf = "Gaussian",
                 abs.ranking = T)
save(ssgsea.res,CESCclinical,file='ssGSEAresult.Rdata')
save(setgenexpr,CESCclinical,file='setgene.Rdata')
