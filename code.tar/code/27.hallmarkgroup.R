rm(list=ls())
load('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/二、宫颈癌缺氧(差异基因+差异基因集)/hallEs.Rdata')
load('PC1score.Rdata')

Mscore <- median(hypoxiaScore$hypoxiaScore,na.rm = FALSE)
group <- as.vector(ifelse((hypoxiaScore$hypoxiaScore)>Mscore,"high","low"))
hypoxiaScoreall <- cbind(hypoxiaScore,group)
hypoxiaScore <- data.frame(hypoxiaScoreall[,2])
rownames(hypoxiaScore) <- rownames(hypoxiaScoreall)
colnames(hypoxiaScore) <- 'group'
##批量检验(三组)
hallscore <- as.data.frame(t(hallEs))
identical(rownames(hypoxiaScore),rownames(hallscore))
hallall <- cbind(hypoxiaScore,hallscore)

##直接用秩和检验
pval=c()
for(i in 2:51){
  #p <- t.test(hallEscluster1[,i],hallEscluster2[,i])$p.value
  p <- wilcox.test(hallall[,i]~hallall$group,data=hallall)$p.value
  
  pval <- c(pval,p)
}
pval <- data.frame(pval)
rownames(pval) <- colnames(hallall[,c(2:51)])
pval$sig <- as.factor(ifelse(pval$pval > 0.05,'ns',
                             ifelse(pval$pval > 0.01,'*',
                                    ifelse(pval$pval>0.001,'**','***'))
))


##可视化
library(ComplexHeatmap)
group1 <- rownames(subset(hypoxiaScore,group=='low'))
group2 <- rownames(subset(hypoxiaScore,group=='high'))

hallES <- hallEs[,c(group1,group2)]
tmp <- apply(hallES,1,scale)
rownames(tmp) <- colnames(hallES)
hallESnorm <- t(tmp)
rownames(hallESnorm) <- gsub('HALLMARK_','',rownames(hallESnorm))
##画热图
##把临床数据搞进来
#调整一下顺序

group <- c(rep('lowscore',148),rep('highscore',148))

#clusteranno <- c(rep('cluster1',112),rep('cluster2',60),rep('cluster3',124))
pathwayanno <- rowAnnotation(
  pval=anno_text(pval$sig,
                 gp=gpar(fontsize=10))
  
)
library(circlize)
colume_ha <- HeatmapAnnotation(
  group=group,
  col=list(
    group=c('highscore'='firebrick','lowscore'='darkblue')
  )
)

Heatmap(hallESnorm,
        name = 'ssGSEA score',
        cluster_columns = F,
        cluster_rows = T,
        show_column_names = F,
        row_names_gp = gpar(
          fontsize=8
        ),
        right_annotation = pathwayanno,
        top_annotation=colume_ha
        
)


library(ggplot2)
hall <- hallall[,c(1,3)]
hall$group <- factor(hall$group,levels = c('high','low'),labels = c('highscore','lowscore'))
g <- ggplot(hall,aes(x=group,y=HALLMARK_HYPOXIA))
library(tibble)
pval <- tibble(
  x=c(1.3,1.7),
  y=c(0.965,0.965)
)
g + geom_boxplot(aes(fill=group),width = 0.7) + 
  scale_fill_manual(values = c('highscore'='firebrick','lowscore'='darkblue'))+
  xlab('hypoxiaScore')+
  ylab('Enrichment Score')+
  labs(title = 'Hypoxia Enrichment')+
  theme(plot.title = element_text(color = 'black',
                                  size=15,
                                  hjust=0.5))+
  #geom_line(data=pval,aes(x=x,y=y,group=1))+#
  annotate('text',x=1.5,y=0.97,label = '***',size=7)+
  guides(fill='none')+
  theme_classic()
