rm(list=ls())
load('estimatehighscore.Rdata')
load('estimatelowscore.Rdata')
estimate <- rbind(highscorescore,lowscorescore)



estimate$group <- c(rep('highscore',148),
                      rep('lowscore',148)
                      )
estimate$group <- factor(estimate$group,levels = c('highscore','lowscore'))
wilcox.test(estimate$ImmuneScore~estimate$group,data=estimate)#无差异
wilcox.test(estimate$ESTIMATEScore~estimate$group,data=estimate)#有差异
wilcox.test(estimate$StromalScore~estimate$group,data=estimate)#有差异

library(ggplot2)
library(pacman)
pacman::p_load(tidyverse,ggpubr,rstatix,ggsci,ggsignif,reshape2)
ggplot(estimate,aes(group,StromalScore,fill=group)) + 
  geom_violin()+
  geom_boxplot(width = 0.2,fill='white') +
  theme_bw()+
  #scale_fill_jco()+
  #geom_jitter(shape=16,size=2,position=position_jitter(0.2))+
  geom_signif(comparisons = list(c('highscore', 'lowscore')
                                 ),
              map_signif_level=T,
              textsize=4,test=t.test,step_increase=0.2)+
  guides(fill=F)+xlab(NULL)+
  scale_fill_manual(values = c('highscore'='firebrick','lowscore'='darkblue'))


ggplot(estimate,aes(group,ImmuneScore,fill=group)) + 
  geom_violin()+
  geom_boxplot(width = 0.2,fill='white') +
  theme_bw()+
  #scale_fill_jco()+
  #geom_jitter(shape=16,size=2,position=position_jitter(0.2))+
  geom_signif(comparisons = list(c('highscore', 'lowscore')
                                ),
              map_signif_level=T,
              textsize=4,test=t.test,step_increase=0.2)+
  guides(fill=F)+xlab(NULL)+
  scale_fill_manual(values = c('highscore'='firebrick','lowscore'='darkblue'))

ggplot(estimate,aes(group,ESTIMATEScore,fill=group)) + 
  geom_violin()+
  geom_boxplot(width = 0.2,fill='white') +
  theme_bw()+
  #scale_fill_jco()+
  #geom_jitter(shape=16,size=2,position=position_jitter(0.2))+
  geom_signif(comparisons = list(c('highscore', 'lowscore')
                                   ),
              map_signif_level=T,
              textsize=4,test=t.test,step_increase=0.2)+
  guides(fill=F)+xlab(NULL)+
  scale_fill_manual(values = c('highscore'='firebrick','lowscore'='darkblue'))

