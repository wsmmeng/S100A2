##参考《PCA的原理和普通实现》https://www.cnblogs.com/leezx/p/6120302.html
##
rm(list=ls())
load('singlecoxresult.Rdata')
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
rownames(CESCfinalfpkm) <- CESCfinalfpkm[,1]
CESCfinalfpkm <- CESCfinalfpkm[,-1]
CESCclinical <- CESCfinalfpkm[,c(1,2)]
CESCexpr <- CESCfinalfpkm[,-c(1:11)]
CESCexpr[1:4,1:4]
CESCexpr <- as.data.frame(t(CESCexpr))
coxgene <- res1$ID
coxgeneset <- CESCexpr[coxgene,]
degexpr <- as.data.frame(t(coxgeneset))

deg.pca<-prcomp(degexpr,scale=T,retx=T) #相关矩阵分解
summary(deg.pca) #方差解释度
deg.pca$sdev #特征值的开方
rotation <- deg.pca$rotation #特征向量，回归系数
score <- deg.pca$x #样本得分score

##选用PC1作为样本的hypoxiaScore
hypoxiaScore <- score[,1]
hypoxiaScore <- as.data.frame(hypoxiaScore)

save(rotation,hypoxiaScore,file='PC1score.Rdata')

