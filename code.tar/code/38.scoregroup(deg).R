##两组数据处理
rm(list=ls())
load('setgene.Rdata')
load('PC1score.Rdata')
load('D:/泛癌免疫浸润(里面有处理突变信息和cluster分组免疫也很规范)/数据准备/CESC.Rdata')

library(limma)
##表达矩阵
rownames(CESCfinal) <- CESCfinal[,1]
CESCfinal <- CESCfinal[,-c(1:14)]
expr <- as.data.frame(t(CESCfinal))
expr <- floor(expr)

##分组矩阵
identical(rownames(hypoxiaScore),rownames(CESCclinical))
OS <- cbind(CESCclinical,hypoxiaScore)
Mscore <- median(OS$hypoxiaScore,na.rm = FALSE)
group <- as.vector(ifelse((OS$hypoxiaScore)>Mscore,"high","low"))
scoreall <- cbind(OS,group)

sample <- rownames(scoreall)
group <- scoreall$group
cluster <- data.frame(sample,group)

group <- cluster[,2]
design <- model.matrix(~0+factor(group))
colnames(design)=levels(factor(group))
expr <- expr[,cluster$sample]##注意这个地方表达矩阵的列名一定要和分组矩阵的行名顺序相同


##构建对比矩阵
contrast.matrix<-makeContrasts("high-low",levels=design)

##对基因表达量进行归一化，data为基因表达量
design <- as.data.frame(design)
rownames(design)=colnames(expr)##design就是分组矩阵
v <- voom(expr, design, normalize="quantile")
##step1
fit <- lmFit(v,design)

##step2
fit2 <- contrasts.fit(fit, contrast.matrix)##这一步很重要，大家
fit2 <- eBayes(fit2)  
##step3
tempOutput = topTable(fit2, coef=1, n=Inf)
nrDEG = na.omit(tempOutput)

##第二步 提取差异表达的基因
deg <- nrDEG
##foldchange取2，变化为两倍，log2取1
logFC_t=0.5
deg$g=ifelse(deg$adj.P.Val>0.05,'stable',
             ifelse( deg$logFC > logFC_t,'UP',
                     ifelse( deg$logFC < -logFC_t,'DOWN','stable')))#增加一行g,为上调和下调的信息
table(deg$g)
save(deg,file = 'degscore.Rdata')

##火山图
##参考https://blog.csdn.net/weifanbio/article/details/116739296
#####火山图
rm(list=ls())
load('degscore.Rdata')
library(ggplot2)
dataset <- deg
# 设置pvalue和logFC的阈值
cut_off_pvalue = 0.05
cut_off_logFC = 0.5
dataset$change = dataset$g
ggplot(
  #设置数据
  dataset, 
  aes(x = logFC, 
      y = -log10(adj.P.Val), 
      colour=change)) +
  geom_point(alpha=0.4, size=3.5) +
  scale_color_manual(values=c("#D6604D", "#d2dae2","#4393C3"))+
  
  # 辅助线
  geom_vline(xintercept=c(-1,1),lty=4,col="black",lwd=0.8) +
  geom_hline(yintercept = -log10(cut_off_pvalue),lty=4,col="black",lwd=0.8) +
  
  # 坐标轴
  labs(x="log2(fold change)",
       y="-log10 (p-value)")+
  theme_bw()+
  
  # 图例
  theme(plot.title = element_text(hjust = 0.5), 
        legend.position="right", 
        legend.title = element_blank()
  )


###差异基因KEGG和GO分析
###参考《使用clusterProfiler进行GO富集分析》https://blog.csdn.net/weixin_43569478/article/details/83744242
###参考《用limma包进行多组差异表达分析》
##参考《ggplot2| 绘制KEGG气泡图》http://www.360doc.com/content/21/0108/14/65403234_955850018.shtml
rm(list = ls())
load('degscore.Rdata')
##第一步 找出差异表达的基因
library(ggplot2)
library(clusterProfiler)
library(org.Hs.eg.db)
##进行ID转换
deg$symbol=rownames(deg)#$是增加一行的意思，增加一行symbol
##deg行名是symbolID,将symbolID转换成ENTREZID
df <- bitr(unique(deg$symbol), fromType = "SYMBOL",
           toType = c( "ENTREZID"),
           OrgDb = org.Hs.eg.db)#进行id转换，可在symbol,ENTREZID,SYMBOL中转换


##将差异表达基因与ENTREZID合并

deg=merge(deg,df,by.y='SYMBOL',by.x='symbol')


##提取出上调下调基因
gene_up= deg[deg$g == 'UP','ENTREZID'] 
gene_down=deg[deg$g == 'DOWN','ENTREZID'] 
gene_diff=c(gene_up,gene_down)
gene_all=as.character(deg[ ,'ENTREZID'] )



## 第三步 KEGG pathway analysis并画气泡图
### 做KEGG数据集超几何分布检验分析，重点在结果的可视化及生物学意义的理解。
if(T){
  ###   over-representation test
  kk.up <- enrichKEGG(gene         = gene_up,
                      organism     = 'hsa',
                      universe     = gene_all,
                      pvalueCutoff = 0.1,
                      qvalueCutoff =0.1)
  head(kk.up)[,1:6]
  dotplot(kk.up )
  kk.down <- enrichKEGG(gene         =  gene_down,
                        organism     = 'hsa',
                        universe     = gene_all,
                        pvalueCutoff = 0.05,
                        qvalueCutoff =0.05)
  head(kk.down)[,1:6]
  dotplot(kk.down )
  kk.diff <- enrichKEGG(gene         = gene_diff,
                        organism     = 'hsa',
                        universe     = gene_all,
                        pvalueCutoff = 0.1,
                        qvalueCutoff =0.1)
  head(kk.diff)[,1:6]
  dotplot(kk.diff,showCategory = 10)
  ##因为有一些很怪异的通路，所以需要手动选择一下
  write.csv(kk.diff@result,'KEGG.csv')
  library(ggplot2)
  pathway = read.csv("KEGGselect.csv",header=TRUE,check.names = FALSE)
  
  library(DOSE)
  pathway$GeneRatio <- parse_ratio(pathway$GeneRatio)
  pathway$GeneRatio <- round(pathway$GeneRatio,digits = 2)
  head(pathway)
  ggplot(pathway,aes(GeneRatio,Description))+
    geom_point(aes(size=Count,color=pvalue))+
    scale_color_gradient(low="green",high = "red")+
    theme(axis.text.y=element_text(vjust=1,size=40,face = "bold"))+#
    labs(color=expression(pvalue),size="Count", ##expression函数定义函数样式 []添加下标，^添加上标
         x="GeneRatio", ##自定义标轴
         y="",
         title="KEGG Pathway enrichment")+ ##自定义坐标轴
    theme_bw() #去掉背景
  ##第三步 GO分析并画气泡图
  ego <- enrichGO(
    gene          = gene_diff,
    keyType = "ENTREZID",
    OrgDb         = org.Hs.eg.db,
    ont           = "ALL",
    pAdjustMethod = "BH",
    pvalueCutoff  = 0.05,
    qvalueCutoff  = 0.05,
    readable      = TRUE)
  barplot(ego, showCategory = 10)
  write.csv(ego@result,'GO.csv')
  library(ggplot2)
  pathway = read.csv("GOselect.csv",header=TRUE,check.names = FALSE)
  library(DOSE)
  pathway$GeneRatio <- parse_ratio(pathway$GeneRatio)
  pathway$GeneRatio <- round(pathway$GeneRatio,digits = 2)
  head(pathway)
  ggplot(pathway,aes(GeneRatio,Description))+
    geom_point(aes(size=Count,color=pvalue))+
    scale_color_gradient(low="green",high = "red")+
    labs(color=expression(pvalue),size="Count", ##expression函数定义函数样式 []添加下标，^添加上标
         x="GeneRatio", ##自定义标轴
         y="",
         title="GO Pathway enrichment")+ ##自定义坐标轴
    theme_bw() #去掉背景
  
  
  
  riskhighcount <- CESCfinal[rowhigh,]
  risklowcount <- CESCfinal[rowlow,]
  
  riskhighfpkm<- CESCfinalfpkm[rowhigh,]
  risklowfpkm<- CESCfinalfpkm[rowlow,]
  
  
  save(riskhighcount,risklowcount,file='riskscorecount.Rdata')
  save(riskhighfpkm,risklowfpkm,file='riskscorefpkm.Rdata')