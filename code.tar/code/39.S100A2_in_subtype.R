rm(list = ls())
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
load('hypoxia.Rdata')
CESCexpr <- CESCfinalfpkm[,-c(2:12)]
rownames(CESCexpr) <- CESCexpr[,1]
CESCexpr <- CESCexpr[,-1]
expr <- CESCexpr
#colnames(OVfinal)[1:10]
subtype1 <- subset(sample,group==1)
subtype1name <- rownames(subtype1)
subtype1 <- expr[subtype1name,] 
subtype2 <- subset(sample,group==2)
subtype2name <- rownames(subtype2)
subtype2<- expr[subtype2name,] 
subtype3 <- subset(sample,group==3)
subtype3name <- rownames(subtype3)
subtype3<- expr[subtype3name,] 
subtype1 <- as.data.frame(t(subtype1))
subtype2 <- as.data.frame(t(subtype2))
subtype3 <- as.data.frame(t(subtype3))

##特殊分子
subtype1 <- as.data.frame(t(subtype1))
subtype2 <- as.data.frame(t(subtype2))
subtype3 <- as.data.frame(t(subtype3))


##IC
firstS100A2 <- subtype1[,c('S100A2')]
secondS100A2 <- subtype2[,c('S100A2')]
thirdS100A2 <- subtype3[,c('S100A2')]
S100A2 <- c(firstS100A2,secondS100A2,thirdS100A2)
subtype <- c(rep('L-hypoxia',112),rep('H-hypoxia',60),rep('M-hypoxia',124))
S100A2 <- data.frame(S100A2)
S100A2$subtype <- subtype
S100A2$subtype = factor(S100A2$subtype, levels=c('L-hypoxia','H-hypoxia','M-hypoxia'))

pval <- summary(aov(S100A2[,1]~S100A2$subtype))[[1]][1,5]
 
ggplot(data = S100A2, aes(x=subtype,y=S100A2))+
  geom_boxplot(aes(fill=subtype))+
  theme_bw()+
  theme(axis.text.x=element_text(vjust=1,size=10))+
  scale_fill_manual(values = c('L-hypoxia'='#ff7f00','H-hypoxia'='#1f78b4','M-hypoxia'='#B03060'))+
  theme(axis.text.x = element_text(
    size = 10
  ))+
  geom_signif(comparisons = list(c('L-hypoxia', 'H-hypoxia'),
                                 c('L-hypoxia','M-hypoxia'),
                                 c('H-hypoxia','M-hypoxia')),
              map_signif_level=T,
              textsize=4,test=t.test,step_increase=0.2)

