rm(list=ls())
load('D:/泛癌免疫浸润(里面有处理突变信息和cluster分组免疫也很规范)/免疫浸润分析/免疫治疗数据集/IMvigor210.Rdata')

eset <- as.data.frame(t(eset))
eset <- eset[pdata$ID,]
S100A2 <- eset[,c('S100A2')]
res <- pdata$BOR_binary
S100A2 <- data.frame(S100A2,res)

S100A2$res = factor(S100A2$group, levels=c('NR','R'))

wilcox.test(S100A2[,1]~S100A2[,2])

ggplot(data = S100A2, aes(x=res,y=S100A2))+
  geom_boxplot(aes(fill=res))+
  theme_bw()+
  theme(axis.text.x=element_text(vjust=1,size=10))+
  scale_fill_manual(values = c('NR'='lightblue','R'='red'))+
  theme(axis.text.x = element_text(
    size = 10
  ))+
  geom_signif(comparisons = list(c('NR', 'R')
  ),
  map_signif_level=T,
  textsize=4,test=wilcox.test,step_increase=0.2)
