##ESTIMATE算法：使用count值
##参考《使用ESTIMATE计算肿瘤的免疫得分> http://www.bio-info-trainee.com/6602.html
###参考《estimate 算法计算肿瘤纯度》
###网址https://zoyi14.smartapps.cn/pages/note/index?slug=0b1de1427458&origin=share&hostname=baiduboxapp&_swebfr=1
rm(list=ls())
##数据准备：ESTIMATE用count值
load('D:/泛癌免疫浸润(里面有处理突变信息和cluster分组免疫也很规范)/数据准备/CESC.Rdata')
load('PC1score.Rdata')
CESCexpr <- CESCfinal[,-c(2:14)]
rownames(CESCexpr) <- CESCexpr[,1]
CESCexpr <- CESCexpr[,-1]
expr <- CESCexpr

Mscore <- median(hypoxiaScore$hypoxiaScore,na.rm = FALSE)
group <- as.vector(ifelse((hypoxiaScore$hypoxiaScore)>Mscore,"high","low"))
hypoxiaScoreall <- cbind(hypoxiaScore,group)
highscoresample <- rownames(subset(hypoxiaScoreall,group=='high'))
highscore <- expr[highscoresample,]
lowscoresample <- rownames(subset(hypoxiaScoreall,group=='low'))
lowscore <- expr[lowscoresample,]
##高风险组
highscore <- 2^highscore-1
highscore <- as.data.frame(t(highscore))
dat=log2(edgeR::cpm(highscore)+1)
library(estimate)
estimate <- function(dat,pro){
  input.f=paste0(pro,'_estimate_input.txt')
  output.f=paste0(pro,'_estimate_gene.gct')
  output.ds=paste0(pro,'_estimate_score.gct')
  write.table(dat,file = input.f,sep = '\t',quote = F)
  library(estimate)
  filterCommonGenes(input.f=input.f,
                    output.f=output.f ,
                    id="GeneSymbol")
  estimateScore(input.ds = output.f,
                output.ds=output.ds,
                platform="illumina") ## 注意这个platform参数
  scores=read.table(output.ds,skip = 2,header = T)
  rownames(scores)=scores[,1]
  scores=t(scores[,3:ncol(scores)])
  return(scores)
}
pro='highscore'
scores=estimate(dat,pro)
##肿瘤纯度计算
TumorPurity = cos(0.6049872018+0.0001467884 * scores[,3])
head(TumorPurity)
##合并肿瘤纯度和scores
scores <- as.data.frame(scores)
scores$TumorPurity=TumorPurity
highscorescore <- scores



##低风险组
lowscore <- 2^lowscore-1
exprSet <- as.data.frame(t(lowscore))
dat=log2(edgeR::cpm(exprSet)+1)
library(estimate)
estimate <- function(dat,pro){
  input.f=paste0(pro,'_estimate_input.txt')
  output.f=paste0(pro,'_estimate_gene.gct')
  output.ds=paste0(pro,'_estimate_score.gct')
  write.table(dat,file = input.f,sep = '\t',quote = F)
  library(estimate)
  filterCommonGenes(input.f=input.f,
                    output.f=output.f ,
                    id="GeneSymbol")
  estimateScore(input.ds = output.f,
                output.ds=output.ds,
                platform="illumina") ## 注意这个platform参数
  scores=read.table(output.ds,skip = 2,header = T)
  rownames(scores)=scores[,1]
  scores=t(scores[,3:ncol(scores)])
  return(scores)
}
pro='lowscore'
scores=estimate(dat,pro)
##肿瘤纯度计算
TumorPurity = cos(0.6049872018+0.0001467884 * scores[,3])
head(TumorPurity)
##合并肿瘤纯度和scores
scores <- as.data.frame(scores)
scores$TumorPurity=TumorPurity
lowscorescore <- scores


save(highscorescore,file='estimatehighscore.Rdata')
save(lowscorescore,file='estimatelowscore.Rdata')
