##第一步 对表达矩阵进行归一化，MCPcounter包需要归一化
rm(list = ls())
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
load('hypoxia.Rdata')
CESCexpr <- CESCfinalfpkm[,-c(2:12)]
rownames(CESCexpr) <- CESCexpr[,1]
CESCexpr <- CESCexpr[,-1]
expr <- CESCexpr
#colnames(OVfinal)[1:10]
subtype1 <- subset(sample,group==1)
subtype1name <- rownames(subtype1)
subtype1 <- expr[subtype1name,] 
subtype2 <- subset(sample,group==2)
subtype2name <- rownames(subtype2)
subtype2<- expr[subtype2name,] 
subtype3 <- subset(sample,group==3)
subtype3name <- rownames(subtype3)
subtype3<- expr[subtype3name,] 
subtype1 <- as.data.frame(t(subtype1))
subtype2 <- as.data.frame(t(subtype2))
subtype3 <- as.data.frame(t(subtype3))
##第二步 进行分析
##高风险组进行分析
library(curl)
library(MCPcounter)
options(timeout= 4000000)
MCPcountersubtype1 <- MCPcounter.estimate(
  subtype1,
  featuresType=c('HUGO_symbols')[1],          
  probesets=read.table(curl('http://raw.githubusercontent.com/ebecht/MCPcounter/master/Signatures/probesets.txt'),sep='\t',stringsAsFactors=FALSE,colClasses='character'),
  genes=read.table(curl('http://raw.githubusercontent.com/ebecht/MCPcounter/master/Signatures/genes.txt'),sep='\t',stringsAsFactors=FALSE,header=TRUE,colClasses='character',check.names=FALSE)
)
MCPcountersubtype1 <- as.data.frame(t(MCPcountersubtype1))

MCPcountersubtype2 <- MCPcounter.estimate(
  subtype2,
  featuresType=c('HUGO_symbols')[1],          
  probesets=read.table(curl('http://raw.githubusercontent.com/ebecht/MCPcounter/master/Signatures/probesets.txt'),sep='\t',stringsAsFactors=FALSE,colClasses='character'),
  genes=read.table(curl('http://raw.githubusercontent.com/ebecht/MCPcounter/master/Signatures/genes.txt'),sep='\t',stringsAsFactors=FALSE,header=TRUE,colClasses='character',check.names=FALSE)
)
MCPcountersubtype2 <- as.data.frame(t(MCPcountersubtype2))

options(timeout= 4000000)
MCPcountersubtype3 <- MCPcounter.estimate(
  subtype3,
  featuresType=c('HUGO_symbols')[1],          
  probesets=read.table(curl('http://raw.githubusercontent.com/ebecht/MCPcounter/master/Signatures/probesets.txt'),sep='\t',stringsAsFactors=FALSE,colClasses='character'),
  genes=read.table(curl('http://raw.githubusercontent.com/ebecht/MCPcounter/master/Signatures/genes.txt'),sep='\t',stringsAsFactors=FALSE,header=TRUE,colClasses='character',check.names=FALSE)
)
MCPcountersubtype3 <- as.data.frame(t(MCPcountersubtype3))
save(MCPcountersubtype1,MCPcountersubtype2,MCPcountersubtype3,file='MCP.Rdata')

