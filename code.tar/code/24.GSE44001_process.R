rm(list=ls())
load('D:/GEO宫颈癌矩阵/data44001.Rdata')
eset <- data44001[,-c(1:3)]
eset <- as.data.frame(t(eset))
p2g <- function(eset,probe2symbol){
  library(dplyr)
  library(tibble)
  library(tidyr)
  eset <- as.data.frame(eset)
  p2g_eset <- eset %>% 
    rownames_to_column(var="PROBE_ID") %>% #合并探针的信息
    inner_join(probe2symbol,by="PROBE_ID") %>% #去掉多余信息
    select(-PROBE_ID) %>% #重新排列
    dplyr::select(SYMBOL_ID,everything()) %>% #求出平均数(这边的点号代表上一步产出的数据)
    mutate(rowMean = rowMeans(.[grep("GSM", names(.))])) %>% #去除symbol中的NA
    filter(SYMBOL_ID != "NA") %>% #把表达量的平均值按从大到小排序
    arrange(desc(rowMean)) %>% # symbol留下第一个
    distinct(SYMBOL_ID,.keep_all = T) %>% #反向选择去除rowMean这一列
    dplyr::select(-rowMean) %>% # 列名变成行名
    column_to_rownames(var = "SYMBOL_ID")
  
  return(p2g_eset)
}

expr44001 <- p2g(eset = eset, probe2symbol = anno44001)
clinical <- data44001[,c(1:3)]
save(expr44001,clinical,file='GSE44001.Rdata')##不保存了