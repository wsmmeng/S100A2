rm(list=ls())
load('xcell.Rdata')
subtype <- c(rep('L-hypoxia',112),rep('H-hypoxia',60),rep('M-hypoxia',124))
xcell <- rbind(xCellsubtype1,xCellsubtype2,xCellsubtype3)


xcellall <- cbind(subtype,xcell)

xcell <- as.data.frame(t(xcell))
xcellcellsc <- apply(xcell,1,scale)
rownames(xcellcellsc) <- colnames(xcell)
xcellcell <- as.data.frame(t(xcellcellsc))##归一化

##单独对细胞画热图
#确定颜色
library(ComplexHeatmap)
library(circlize)
col1 <- colorRamp2(
  c(-4,0,4),
  c('blue','white','red')
)
#确定注释
#列的注释
column_ha <- HeatmapAnnotation(
  
  subtype=subtype,
  col = list(
    subtype=c('L-hypoxia'='#ff7f00','H-hypoxia'='#1f78b4','M-hypoxia'='#B03060')
  ))
#行的注释
#进行批量T检验
pval <- c()
for(i in c(2:68)){
  p=summary(aov(xcellall[,i]~xcellall$subtype))[[1]][1,5]
  #存放p值
  pval=c(pval,p)
}
pval <- as.data.frame(pval)
rownames(pval) <- colnames(xcellall)[2:68]
#替换成*号
pval$mark <- as.factor(ifelse(pval$pval > 0.05,'ns',
                              ifelse(pval$pval> 0.01,'*',
                                     ifelse(pval$pval>0.001,'**','***'))
))
pvalxcell <- pval
#行的注释
ha <- rowAnnotation(
  p = anno_text(
    pval$mark,
    location = 0.3,
    gp=gpar(
      fontsize = 7
    )
  )
)
Heatmap(xcellcell)
xcellpic <- Heatmap(xcellcell,name = 'xcell',
                  col = col1,
                  row_title = 'xcell',
                  cluster_columns = F,
                  cluster_rows = T,
                  show_column_names = F,
                  row_names_gp = gpar(
                    fontsize = 7),
                  right_annotation = ha,
                  top_annotation = column_ha,
                  
)

draw(xcellpic)
save(xcellpic,file='xcellpic.Rdata')

