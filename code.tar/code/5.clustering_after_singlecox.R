##重新聚类
rm(list=ls())
load('deg1c2.Rdata')
load('deg1c3.Rdata')
load('deg2c3.Rdata')

mark <- c('UP','DOWN')
dn1c2 <- rownames(deg1c2[which(deg1c2$g %in% mark),])
dn1c3 <- rownames(deg1c3[which(deg1c3$g %in% mark),])
dn2c3 <- rownames(deg2c3[which(deg2c3$g %in% mark),])

dn <- c(dn1c2,dn1c3,dn2c3)
dn <- dn[!duplicated(dn)]

load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
rownames(CESCfinalfpkm) <- CESCfinalfpkm[,1]
CESCfinalfpkm <- CESCfinalfpkm[,-1]
CESCclinical <- CESCfinalfpkm[,c(1,2)]
CESCexpr <- CESCfinalfpkm[,-c(1:11)]
CESCexpr[1:4,1:4]
CESCexpr <- as.data.frame(t(CESCexpr))
dngeneset <- CESCexpr[dn,]

save(dn,file='degcluster.Rdata')

##单因素cox回归
deggenexpr <- CESCexpr[dn,]
deggenexpr <- as.data.frame(t(deggenexpr))
singlecox <- cbind(CESCclinical,deggenexpr)
colnames(singlecox) <- gsub('-','_',colnames(singlecox))##需要换一下，不然会报错
library(dplyr)
library(tidyr)
library(tibble)

#转换完成，导入R
genes<- colnames(singlecox)[-c(1:2)]
#提取基因名，一二列不是基因名
library(survival)
#for循环
res<-data.frame()
for(i in 1:length(genes)){
  print(i)
  surv=as.formula(paste('Surv(OS.time,OS)~',genes[i]))
  x = coxph(surv,data = singlecox)##surv函数默认生存是0，死亡是1
  x = summary(x)
  p.value=signif(x$wald["pvalue"],digits = 3)
  HR =signif(x$coef[2],digits = 3)
  HR.confint.lower = signif(x$conf.int[,"lower .95"],3)
  HR.confint.upper = signif(x$conf.int[,"upper .95"],3)
  CI <- paste0("(",HR.confint.lower,"-",HR.confint.upper,")")
  res[i,1] = genes[i]
  res[i,2] = HR
  res[i,3] = CI
  res[i,4] = p.value
}
#会显示i,i的数值应该跟需要分析的lncRNA数目抑制
names(res) <- c("ID","HR","95% CI","p.value")

res1<-res%>%
  filter(p.value<0.05)
res1$ID <- gsub('_','-',res1$ID)##需要换回来


#过滤
save(res1,file ='singlecoxresult.Rdata')



##聚类
coxgene <- res1$ID
coxgeneset <- CESCexpr[coxgene,]
library(CancerSubtypes)
coxgeneset <- as.matrix(coxgeneset)
####check distribution
data.checkDistribution(coxgeneset)
###Feature selection by most variance
coxgeneset_F=FSbyVar(coxgeneset, cut.type = "topk",4000)
#index7=match(rownames(GBM_mRNA_Tumor1),rownames(GBM_mRNA_Normal))
#GBM_mRNA_Normal1=GBM_mRNA_Normal[index7,]
##data normalization
coxgeneset_norm=data.normalization(coxgeneset)

###！注意再这中间运用要计算一个K值，也就是cluster的个数,但我算出来是2,帮助文档是3
library(factoextra)
#前面已经标准化了，如果没有标准化要标准化
tumor <- as.data.frame(t(GBM_mRNA_Tumor_norm))
library(factoextra)
fviz_nbclust(tumor, kmeans, method = "silhouette")
km.res <- kmeans(tumor,2)
fviz_cluster(km.res, data = tumor,labelsize = 1)
###！

######Concensus clustering
result1=ExecuteCC(clusterNum=3,d=coxgeneset_norm,maxK=5,
                  clusterAlg="hc",distance="pearson",title="deg")##注意必须是矩阵而不是数据框
group=result1$group
table(group)

###result validation and visualization
distanceMatrix=result1$distanceMatrix
p_value=survAnalysis(mainTitle="DEG",CESCclinical$OS.time,
                     CESCclinical$OS,group,
                     distanceMatrix=distanceMatrix,similarity=TRUE)
saveFigure(foldername="deg",filename="deg",image_width=7,
           image_height=7,image_res=300)
sample <- as.data.frame(result1[["group"]])
colnames(sample)='group'
resultdeg <- result1
sampledeg <- sample
groupdeg <- group

save(resultdeg,sampledeg,groupdeg,file='deghypoxia.Rdata')
