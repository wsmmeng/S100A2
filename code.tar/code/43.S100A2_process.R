###合并，可视化；打分；S100A2分布(UMAP)均已经完成
###S100A2的分布(小提琴图)，及功能
rm(list=ls())
library(Seurat)
CESC <- readRDS('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/八、宫颈癌单细胞探索2/CESC.rds')
VlnPlot(CESC,features = c('S100A2'),pt.size = 0, adjust = 2,group.by = "celltype")
