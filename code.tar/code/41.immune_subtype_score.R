##参考《跟着Cell学单细胞转录组分析(十一):单细胞基因评分|AUCell评分》

rm(list = ls (all = TRUE))
##用AddModuleScore函数计算衰老评分

library(monocle)
library(Seurat)
CESC <- readRDS("E:/宫颈癌各种数据集探索/宫颈癌缺氧全/八、宫颈癌单细胞探索2/CESC.rds")


DefaultAssay(CESC) <- "RNA"
load("E:/宫颈癌各种数据集探索/宫颈癌缺氧全/八、宫颈癌单细胞探索2/degimmune.Rdata")
##第二步 提取差异表达的基因
#degimmune <- nrDEG
##foldchange取2，变化为两倍，log2取1
logFC_t=0.5
##第二步 提取差异表达的基因
degimmune$g=ifelse(##第二步 提取差异表达的基因
  degimmune$P.Value>0.05,'stable',
  ifelse( ##第二步 提取差异表达的基因
    degimmune$logFC > logFC_t,'UP',
    ifelse( ##第二步 提取差异表达的基因
      degimmune$logFC < -logFC_t,'DOWN','stable')))#增加一行g,为上调和下调的信息
table(degimmune$g)

##因为对比矩阵是Resistent对sensitive,所以上调的是铂耐药
#degname <- subset(degimmune,g=='UP'|g=='DOWN')
#degname <- subset(degimmune,g=='UP')
degname <- subset(degimmune,g=='DOWN')
gene_symbol <- rownames(degname)

immunetherapy_features <- list(gene_symbol)

immunetherapyscore <- AddModuleScore(CESC,
                                     features = immunetherapy_features,
                                     ctrl = 100,
                                     name = "immunetherapy_Features")

colnames(immunetherapyscore@meta.data)
colnames(immunetherapyscore@meta.data)[14] <- 'immunetherapy_Score'
Idents(CESC) <- 'celltype'
VlnPlot(immunetherapyscore,features = 'immunetherapy_Score',pt.size = 0, adjust = 2,group.by = "celltype")


library(ggplot2)
mydata<- FetchData(immunetherapyscore,vars = c("UMAP_1","UMAP_2","immunetherapy_Score"))
a <- ggplot(mydata,aes(x = UMAP_1,y =UMAP_2,colour = immunetherapy_Score))+
  geom_point(size = 1)+scale_color_gradientn(values = seq(0,1,0.2),
                                             
                                             colours = c('#333366',"#6666FF",'#CC3333','#FFCC33'))
a+ theme_bw() + theme(panel.grid.major = element_blank(),
                      panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"),
                      panel.border = element_rect(fill=NA,color="black", size=1, linetype="solid"))


DefaultAssay(CESC) <- "RNA"
load("degscore.Rdata")
##第二步 提取差异表达的基因
#degimmune <- nrDEG
##foldchange取2，变化为两倍，log2取1
logFC_t=0
##第二步 提取差异表达的基因
deg$g=ifelse(##第二步 提取差异表达的基因
  deg$P.Value>0.05,'stable',
  ifelse( ##第二步 提取差异表达的基因
    deg$logFC > logFC_t,'UP',
    ifelse( ##第二步 提取差异表达的基因
      deg$logFC < -logFC_t,'DOWN','stable')))#增加一行g,为上调和下调的信息
table(deg$g)

##因为对比矩阵是Resistent对sensitive,所以上调的是铂耐药
#degname <- subset(deg,g=='UP'|g=='DOWN')
#degname <- subset(deg,g=='UP')
degname <- subset(deg,g=='DOWN')
gene_symbol <- rownames(degname)

hypoxiascore_features <- list(gene_symbol)

hypoxiascorescore <- AddModuleScore(CESC,
                                    features = hypoxiascore_features,
                                    ctrl = 100,
                                    name = "hypoxiascore_Features")

colnames(hypoxiascorescore@meta.data)
colnames(hypoxiascorescore@meta.data)[14] <- 'hypoxiascore_Score'

VlnPlot(hypoxiascorescore,features = 'hypoxiascore_Score',pt.size = 0, adjust = 2,group.by = "celltype")


library(ggplot2)
mydata<- FetchData(hypoxiascorescore,vars = c("UMAP_1","UMAP_2","hypoxiascore_Score"))
a <- ggplot(mydata,aes(x = UMAP_1,y =UMAP_2,colour = hypoxiascore_Score))+
  geom_point(size = 1)+scale_color_gradientn(values = seq(0,1,0.2),
                                             colours = c('#333366',"#6666FF",'#CC3333','#FFCC33'))
a+ theme_bw() + theme(panel.grid.major = element_blank(),
                      panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"),
                      panel.border = element_rect(fill=NA,color="black", size=1, linetype="solid"))

