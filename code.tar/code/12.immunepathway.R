##参考《GSVA + limma进行差异通路分析》
rm(list=ls())
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
rownames(CESCfinalfpkm) <- CESCfinalfpkm[,1]
CESCfinalfpkm <- CESCfinalfpkm[,-1]
CESCexpr <- CESCfinalfpkm[,-c(1:11)]
CESCexpr[1:4,1:4]
CESCexpr <- as.data.frame(t(CESCexpr))

##第一步计算ssGSEA评分
library(GSVA)
library(GSEABase)
immuneSet <- getGmt("E:/宫颈癌各种数据集探索/宫颈癌缺氧全/二、宫颈癌缺氧(差异基因+差异基因集)/c7.all.v7.4.symbols.gmt")
immuneEs <- gsva(expr=as.matrix(CESCexpr), gset.idx.list=immuneSet,method='ssgsea', kcdf="Gaussian", parallel.sz=4)
save(immuneEs,file='immuneEs.Rdata')


load('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/二、宫颈癌缺氧(差异基因+差异基因集)/immuneEs.Rdata')
load('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/一、宫颈癌缺氧(聚类分析+基因组+免疫治疗组)/hypoxia.Rdata')

##批量检验(三组)
immunescore <- as.data.frame(t(immuneEs))
identical(rownames(immunescore),rownames(sample))
immuneall <- cbind(sample,immunescore)
##直接用秩和检验
pval=c()
for(i in 2:5220){
  #根据type来将样本分成两组
  p=summary(aov(immuneall[,i]~immuneall$group))[[1]][1,5]
  #存放p值
  pval=c(pval,p)
}
pval <- data.frame(pval)
rownames(pval) <- colnames(immuneall[,c(2:5220)])
pval$sig <- as.factor(ifelse(pval$pval > 0.05,'ns',
                             ifelse(pval$pval > 0.01,'*',
                                    ifelse(pval$pval>0.001,'**','***'))
))
##取前50个pvalue最小的通路
pval <- pval[order(pval$pval),]
pval<- pval[c(1:50),]

sigpath <- rownames(pval)
immuneEs <- immuneEs[sigpath,]##这里immuneEs变成了前50个通路，因为懒得改变量名
#write.csv(immuneEs,'immuneEs.csv')
immuneEs <- read.csv('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/二、宫颈癌缺氧(差异基因+差异基因集)/immuneEs.csv',header = T,row.names = 1)
immuneEs <- as.matrix(immuneEs)
##可视化
cluster1 <- rownames(subset(sample,group=='1'))
cluster2 <- rownames(subset(sample,group=='2'))
cluster3 <- rownames(subset(sample,group=='3'))
immuneES <- immuneEs[,c(cluster1,cluster2,cluster3)]
tmp <- apply(immuneES,1,scale)
rownames(tmp) <- colnames(immuneES)
immuneESnorm <- t(tmp)

###全部免疫通路可视化

{immuneES <- as.data.frame(t(immuneall))
subtype1 <- rownames(subset(sample,group=='1'))
subtype2 <- rownames(subset(sample,group=='2'))
subtype3 <- rownames(subset(sample,group=='3'))
immuneES <- immuneEs[,c(subtype1,subtype2,subtype3)]
tmp <- apply(immuneES,1,scale)
rownames(tmp) <- colnames(immuneES)
immuneESnorm <- t(tmp)
}
##画热图
{##把临床数据搞进来
clinical <- read.csv('clinical.csv',header=T,row.names = 1)
clinical <- clinical[,c(2,4,5,6,7,8)]
clinical[clinical=='stage1']='stageⅠ'
clinical[clinical=='stage2']='stageⅡ'
clinical[clinical=='stage3']='stageⅢ'
clinical[clinical=='stage4']='stageⅣ'
}
#调整一下顺序
#clinical <- clinical[colnames(immuneESnorm),]
subtype <- c(rep("L-hypoxia",112),rep('H-hypoxia',60),rep('M-hypoxia',124))
#dfanno <- cbind(clinical,subtype)

library(ComplexHeatmap)

#clusteranno <- c(rep('cluster1',112),rep('cluster2',60),rep('cluster3',124))

pathwayanno <- rowAnnotation(
  pval=anno_text(pval$sig,
                 gp=gpar(fontsize=7))
  
)
library(circlize)
col_fun <- colorRamp2(
  breaks = c(-4,0,4),
  colors = c('blue','white','red')
)
#lgd <- Legend(col_fun = col_fun,title = 'ssGSEA score' )
#col_fun <- colorRamp2(
#breaks = c(-4,0,4),
#colors = c('blue','white','red')
#)
#lgd2 <- legend(
#labels=c('cluster1','cluster2','cluster3'),
#title='cluster',
#legend_gp = gpar(fill=)
#)
library(circlize)
colume_ha <- HeatmapAnnotation(
  subtype=subtype,
  col=list(
    subtype=c('L-hypoxia'='#ff7f00','H-hypoxia'='#1f78b4','M-hypoxia'='#B03060')
  )
)
Heatmap(immuneESnorm)
Heatmap(immuneESnorm,
        name = 'ssGSEA score',
        cluster_columns = F,
        show_column_names = F,
        show_row_names = F,
        row_names_gp = gpar(
          fontsize=5
        ),
        #right_annotation = pathwayanno,
        top_annotation=colume_ha
        
)

