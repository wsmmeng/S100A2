##参考《GSVA + limma进行差异通路分析》
rm(list=ls())
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
rownames(CESCfinalfpkm) <- CESCfinalfpkm[,1]
CESCfinalfpkm <- CESCfinalfpkm[,-1]
CESCexpr <- CESCfinalfpkm[,-c(1:11)]
CESCexpr[1:4,1:4]
CESCexpr <- as.data.frame(t(CESCexpr))

##第一步计算ssGSEA评分
library(GSVA)
library(GSEABase)
hallSet <- getGmt("E:/宫颈癌各种数据集探索/宫颈癌缺氧全/一、宫颈癌缺氧(聚类分析+基因组+免疫治疗组)/h.all.v7.4.symbols.gmt")
hallEs <- gsva(expr=as.matrix(CESCexpr), gset.idx.list=hallSet,method='ssgsea', kcdf="Gaussian", parallel.sz=4)
save(hallEs,file='hallEs.Rdata')
load('hallEs.Rdata')
load('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/一、宫颈癌缺氧(聚类分析+基因组+免疫治疗组)/hypoxia.Rdata')

##批量检验(三组)
hallscore <- as.data.frame(t(hallEs))
identical(rownames(hallscore),rownames(sample))
hallall <- cbind(sample,hallscore)
##直接用秩和检验
pval=c()
for(i in c(2:51)){
  #根据type来将样本分成两组
  p=summary(aov(hallall[,i]~hallall$group))[[1]][1,5]
  #存放p值
  pval=c(pval,p)
}
pval <- data.frame(pval)
rownames(pval) <- colnames(hallall[,c(2:51)])
pval$sig <- as.factor(ifelse(pval$pval > 0.05,'ns',
                             ifelse(pval$pval > 0.01,'*',
                                    ifelse(pval$pval>0.001,'**','***'))
))

##可视化
cluster1 <- rownames(subset(sample,group=='1'))
cluster2 <- rownames(subset(sample,group=='2'))
cluster3 <- rownames(subset(sample,group=='3'))
hallES <- hallEs[,c(cluster1,cluster2,cluster3)]
tmp <- apply(hallES,1,scale)
rownames(tmp) <- colnames(hallES)
hallESnorm <- t(tmp)
rownames(hallESnorm) <- gsub('HALLMARK_','',rownames(hallESnorm))
##画热图
##把临床数据搞进来
clinical <- read.csv('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/二、宫颈癌缺氧(差异基因+差异基因集)/clinical.csv',header=T,row.names = 1)
clinical <- clinical[,c(2,4,5,6,7,8)]
clinical[clinical=='stage1']='stageⅠ'
clinical[clinical=='stage2']='stageⅡ'
clinical[clinical=='stage3']='stageⅢ'
clinical[clinical=='stage4']='stageⅣ'
#调整一下顺序
clinical <- clinical[colnames(hallESnorm),]
subtype <- c(rep('subtype1',112),rep('subtype2',60),rep('subtype3',124))
dfanno <- cbind(clinical,subtype)

library(ComplexHeatmap)
table(sample$group)
#clusteranno <- c(rep('cluster1',112),rep('cluster2',60),rep('cluster3',124))
pathwayanno <- rowAnnotation(
  pval=anno_text(pval$sig,
                 gp=gpar(fontsize=10))
  
)
library(circlize)
colume_ha <- HeatmapAnnotation(
  subtype=dfanno$subtype,
  col=list(
    subtype=c('subtype1'='#ff7f00','subtype2'='#1f78b4','subtype3'='#B03060')
  )
)

Heatmap(hallESnorm,
        name = 'ssGSEA score',
        cluster_columns = F,
        show_column_names = F,
        row_names_gp = gpar(
          fontsize=8
        ),
        right_annotation = pathwayanno,
        top_annotation=colume_ha
        
)
