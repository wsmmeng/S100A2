##ESTIMATE算法：使用count值
##参考《使用ESTIMATE计算肿瘤的免疫得分> http://www.bio-info-trainee.com/6602.html
###参考《estimate 算法计算肿瘤纯度》
###网址https://zoyi14.smartapps.cn/pages/note/index?slug=0b1de1427458&origin=share&hostname=baiduboxapp&_swebfr=1
rm(list=ls())
##数据准备：ESTIMATE用count值
load('D:/泛癌免疫浸润(里面有处理突变信息和cluster分组免疫也很规范)/数据准备/CESC.Rdata')
load('hypoxia.Rdata')
CESCexpr <- CESCfinal[,-c(2:14)]
rownames(CESCexpr) <- CESCexpr[,1]
CESCexpr <- CESCexpr[,-1]
expr <- CESCexpr
#colnames(OVfinal)[1:10]
subtype1 <- subset(sample,group==1)
subtype1name <- rownames(subtype1)
subtype1 <- expr[subtype1name,] 
subtype2 <- subset(sample,group==2)
subtype2name <- rownames(subtype2)
subtype2<- expr[subtype2name,] 
subtype3 <- subset(sample,group==3)
subtype3name <- rownames(subtype3)
subtype3<- expr[subtype3name,] 
##高风险组
subtype1 <- 2^subtype1-1
subtype1 <- as.data.frame(t(subtype1))
dat=log2(edgeR::cpm(subtype1)+1)
library(estimate)
estimate <- function(dat,pro){
  input.f=paste0(pro,'_estimate_input.txt')
  output.f=paste0(pro,'_estimate_gene.gct')
  output.ds=paste0(pro,'_estimate_score.gct')
  write.table(dat,file = input.f,sep = '\t',quote = F)
  library(estimate)
  filterCommonGenes(input.f=input.f,
                    output.f=output.f ,
                    id="GeneSymbol")
  estimateScore(input.ds = output.f,
                output.ds=output.ds,
                platform="illumina") ## 注意这个platform参数
  scores=read.table(output.ds,skip = 2,header = T)
  rownames(scores)=scores[,1]
  scores=t(scores[,3:ncol(scores)])
  return(scores)
}
pro='subtype1'
scores=estimate(dat,pro)
##肿瘤纯度计算
TumorPurity = cos(0.6049872018+0.0001467884 * scores[,3])
head(TumorPurity)
##合并肿瘤纯度和scores
scores <- as.data.frame(scores)
scores$TumorPurity=TumorPurity
subtype1score <- scores



##低风险组
subtype2 <- 2^subtype2-1
exprSet <- as.data.frame(t(subtype2))
dat=log2(edgeR::cpm(exprSet)+1)
library(estimate)
estimate <- function(dat,pro){
  input.f=paste0(pro,'_estimate_input.txt')
  output.f=paste0(pro,'_estimate_gene.gct')
  output.ds=paste0(pro,'_estimate_score.gct')
  write.table(dat,file = input.f,sep = '\t',quote = F)
  library(estimate)
  filterCommonGenes(input.f=input.f,
                    output.f=output.f ,
                    id="GeneSymbol")
  estimateScore(input.ds = output.f,
                output.ds=output.ds,
                platform="illumina") ## 注意这个platform参数
  scores=read.table(output.ds,skip = 2,header = T)
  rownames(scores)=scores[,1]
  scores=t(scores[,3:ncol(scores)])
  return(scores)
}
pro='subtype2'
scores=estimate(dat,pro)
##肿瘤纯度计算
TumorPurity = cos(0.6049872018+0.0001467884 * scores[,3])
head(TumorPurity)
##合并肿瘤纯度和scores
scores <- as.data.frame(scores)
scores$TumorPurity=TumorPurity
subtype2score <- scores


##低风险组
subtype3 <- 2^subtype3-1
exprSet <- as.data.frame(t(subtype3))
dat=log2(edgeR::cpm(exprSet)+1)
library(estimate)
estimate <- function(dat,pro){
  input.f=paste0(pro,'_estimate_input.txt')
  output.f=paste0(pro,'_estimate_gene.gct')
  output.ds=paste0(pro,'_estimate_score.gct')
  write.table(dat,file = input.f,sep = '\t',quote = F)
  library(estimate)
  filterCommonGenes(input.f=input.f,
                    output.f=output.f ,
                    id="GeneSymbol")
  estimateScore(input.ds = output.f,
                output.ds=output.ds,
                platform="illumina") ## 注意这个platform参数
  scores=read.table(output.ds,skip = 2,header = T)
  rownames(scores)=scores[,1]
  scores=t(scores[,3:ncol(scores)])
  return(scores)
}
pro='subtype3'
scores=estimate(dat,pro)
##肿瘤纯度计算
TumorPurity = cos(0.6049872018+0.0001467884 * scores[,3])
head(TumorPurity)
##合并肿瘤纯度和scores
scores <- as.data.frame(scores)
scores$TumorPurity=TumorPurity
subtype3score <- scores

save(subtype1score,file='estimatesubtype1.Rdata')
save(subtype2score,file='estimatesubtype2.Rdata')
save(subtype3score,file='estimatesubtype3.Rdata')




