rm(list=ls())
load('setgene.Rdata')
load('PC1score.Rdata')
identical(rownames(hypoxiaScore),rownames(CESCclinical))

OS <- cbind(CESCclinical,hypoxiaScore)

##KM生存曲线
library(survminer) # 加载包
library(survival) # 加载包

##对score画生存曲线
Mscore <- median(OS$hypoxiaScore,na.rm = FALSE)
group <- as.vector(ifelse((OS$hypoxiaScore)>Mscore,"high","low"))
OSall <- cbind(OS,group)
fit <- survfit(Surv(OS.time,OS) ~ group,  # 创建生存对象 
               data = OSall) # 数据集来源
ggsurvplot(fit,pval = TRUE,title='                              hypoxiaScore',
           conf.int = TRUE,
           xlab = "Follow up time(day)",
           ylab = "survival probability",
           surv.median.line = "hv",
           palette = "aaas",
           risk.table = T)
##确实是有差异的


clinical <- read.csv('E:/宫颈癌各种数据集探索/宫颈癌缺氧全/一、宫颈癌缺氧(聚类分析+基因组+免疫治疗组)/clinical.csv',header=T,row.names = 1)
clinical[clinical=='stage1']='stageⅠ'
clinical[clinical=='stage2']='stageⅡ'
clinical[clinical=='stage3']='stageⅢ'
clinical[clinical=='stage4']='stageⅣ'
identical(rownames(OS),rownames(clinical))
clinical <- cbind(OS,clinical)
clinical <- clinical[,-c(4,6)]
##relevel函数用法
##参考https://bbs.pinggu.org/thread-816000-1-1.html
clinical$Chemoreactivity <- as.factor(clinical$Chemoreactivity)
clinical$Chemoreactivity <- relevel(clinical$Chemoreactivity,ref = 'NR')
clinical$stage <- as.factor(clinical$stage)
clinical$stage <- relevel(clinical$stage,ref = 'stageⅠ')
clinical$grade <- as.factor(clinical$grade)
clinical$grade <- relevel(clinical$grade,ref = 'G1')
clinical$pathologic_M<- as.factor(clinical$pathologic_M)
clinical$pathologic_M <- relevel(clinical$pathologic_M,ref = 'M0')
clinical$pathologic_N<- as.factor(clinical$pathologic_N)
clinical$pathologic_N <- relevel(clinical$pathologic_N,ref = 'N0')
clinical$pathologic_T<- as.factor(clinical$pathologic_T)
clinical$pathologic_T<- relevel(clinical$pathologic_T,ref = 'T1')


##hypoxiaScore是独立的危险因素
library(survival)
outTabCESC=data.frame()
for(i in 3:9){
  cox <- coxph(Surv(OS.time, OS) ~ clinical[,i], data = clinical)
  coxSummary = summary(cox)
  coxP=coxSummary$coefficients[,"Pr(>|z|)"]
  outTabCESC=rbind(outTabCESC,
                   cbind(id=colnames(clinical)[i],
                         z=coxSummary$coefficients[,"z"],
                         HR=coxSummary$conf.int[,"exp(coef)"],
                         HR.95L=coxSummary$conf.int[,"lower .95"],
                         HR.95H=coxSummary$conf.int[,"upper .95"],
                         pvalue=coxSummary$coefficients[,"Pr(>|z|)"])
  )
}
outTabCESC <- outTabCESC[-c(2,3,4,10,11,12,14,15,17,18,19,22,23,24),]
ID <- c('hypoxiaScore','stageⅡ','stageⅢ','stageⅣ')
ID2 <- c('G2','G3','M1','N1','T2','T3')
ID <- c(ID,ID2)
outTabCESC$id <- ID
save(outTabCESC,file='单因素CESC.Rdata')


##独立预后因素画森林图
rm(list=ls())
load('单因素CESC.Rdata')
rownames(outTabCESC) <- c(1:10)
library(forestplot)
CESCmeta<- structure(list(
  mean =c(NA, outTabCESC$HR),
  lower =c(NA,outTabCESC$HR.95L),
  upper =c(NA, outTabCESC$HR.95H)),
  .Names =c("mean", "lower", "upper"),
  row.names =c(NA, -11L),##这个地方要比本来的数据多加一行
  class ="data.frame")
CESCmeta$mean <- as.numeric(CESCmeta$mean)
CESCmeta$lower<- as.numeric(CESCmeta$lower)
CESCmeta$upper<- as.numeric(CESCmeta$upper)
CESCmeta <- round(CESCmeta,digits = 4)

outTabCESC$HR <- as.numeric(outTabCESC$HR)
outTabCESC$HR <- round(outTabCESC$HR,digits = 4)
outTabCESC$pvalue <- as.numeric(outTabCESC$pvalue)
outTabCESC$pvalue <- round(outTabCESC$pvalue,digits = 4)
tabletext<-cbind(
  c("character", outTabCESC$id),
  c("HR", outTabCESC$HR),
  c("pvalue", outTabCESC$pvalue))
tabletext[tabletext==0]='<0.001' #方便画图
forestplot(tabletext, graph.pos =2, 
           hrzl_lines =list("2"=gpar(lty=2)
           ),
           CESCmeta,new_page =TRUE,
           is.summary=c(TRUE,rep(FALSE,10)),
           clip=c(0.1,2.5),
           xlog=TRUE,
           col=fpColors(box="royalblue",line="darkblue",summary="royalblue",hrz_lines ="#444444"),
           boxsize=0.1,
           graphwidth=unit(.6,'npc')
)
