rm(list = ls())
load('E:/宫颈癌卵巢癌fpkm表达量基因集(里面也有死亡相关基因)/CESCfpkm.Rdata')
load('hypoxia.Rdata')
CESCexpr <- CESCfinalfpkm[,-c(2:12)]
rownames(CESCexpr) <- CESCexpr[,1]
CESCexpr <- CESCexpr[,-1]
expr <- CESCexpr
#colnames(OVfinal)[1:10]
subtype1 <- subset(sample,group==1)
subtype1name <- rownames(subtype1)
subtype1 <- expr[subtype1name,] 
subtype2 <- subset(sample,group==2)
subtype2name <- rownames(subtype2)
subtype2<- expr[subtype2name,] 
subtype3 <- subset(sample,group==3)
subtype3name <- rownames(subtype3)
subtype3<- expr[subtype3name,] 
subtype1 <- as.data.frame(t(subtype1))
subtype2 <- as.data.frame(t(subtype2))
subtype3 <- as.data.frame(t(subtype3))

##特殊分子
subtype1 <- as.data.frame(t(subtype1))
subtype2 <- as.data.frame(t(subtype2))
subtype3 <- as.data.frame(t(subtype3))


##IC
inhibitor <- c('PDCD1','CTLA4','CD274','HAVCR2','LAG3','TIGIT')
firstinhibitor <- subtype1[,inhibitor]
secondinhabitor <- subtype2[,inhibitor]
thirdinhabitor <- subtype3[,inhibitor]
inhibitor <- rbind(firstinhibitor,secondinhabitor,thirdinhabitor)
subtype <- c(rep('L-hypoxia',112),rep('H-hypoxia',60),rep('M-hypoxia',124))
inhibitor$subtype <- subtype
inhibitor$subtype = factor(inhibitor$subtype, levels=c('L-hypoxia','H-hypoxia','M-hypoxia'))

pval <- c()
for(i in c(1:6)){
  p=summary(aov(inhibitor[,i]~inhibitor$subtype))[[1]][1,5]
  #存放p值
  pval=c(pval,p)
}
pval <- as.data.frame(pval)
rownames(pval) <- colnames(inhibitor)[1:6]
#替换成*号
pval$mark <- as.factor(ifelse(pval$pval > 0.05,'ns',
                              ifelse(pval$pval> 0.01,'*',
                                     ifelse(pval$pval>0.001,'**','***'))
))
pvalimmune <- pval


library(reshape2)
inhibitormelt <- melt(inhibitor,id.vars=c("subtype"),
                   measure.vars = colnames(inhibitor)[1:6],variable.name = "inhibitor",value.name = "expression")
ggplot(data = inhibitormelt, aes(x=inhibitor,y=expression))+
  geom_boxplot(aes(fill=subtype))+
  theme_bw()+
  theme(axis.text.x=element_text(vjust=1,size=10))+
  scale_fill_manual(values = c('L-hypoxia'='#ff7f00','H-hypoxia'='#1f78b4','M-hypoxia'='#B03060'))+
  annotate('text',x='PDCD1',y=7.5,label = 'ns',size=5)+
  annotate('text',x='CTLA4',y=7.5,label = '*',size=5)+
  annotate('text',x='CD274',y=7.5,label = '***',size=5)+
  annotate('text',x='HAVCR2',y=7.5,label = '**',size=5)+
  annotate('text',x='LAG3',y=7.5,label = 'ns',size=5)+
  annotate('text',x='TIGIT',y=7.5,label = 'ns',size=5)+
  theme(axis.text.x = element_text(
    size = 10
  ))

##
ef <- c('GZMB','PRF1','TNF','IFNG','LAMP1')
firstef <- subtype1[,ef]
secondinhabitor <- subtype2[,ef]
thirdinhabitor <- subtype3[,ef]
ef <- rbind(firstef,secondinhabitor,thirdinhabitor)
subtype <- c(rep('L-hypoxia',112),rep('H-hypoxia',60),rep('M-hypoxia',124))
ef$subtype <- subtype
ef$subtype = factor(ef$subtype, levels=c('L-hypoxia','H-hypoxia','M-hypoxia'))

pval <- c()
for(i in c(1:5)){
  p=summary(aov(ef[,i]~ef$subtype))[[1]][1,5]
  #存放p值
  pval=c(pval,p)
}
pval <- as.data.frame(pval)
rownames(pval) <- colnames(ef)[1:5]
#替换成*号
pval$mark <- as.factor(ifelse(pval$pval > 0.05,'ns',
                              ifelse(pval$pval> 0.01,'*',
                                     ifelse(pval$pval>0.001,'**','***'))
))
pvalef <- pval


library(reshape2)
efmelt <- melt(ef,id.vars=c("subtype"),
               measure.vars = colnames(ef)[1:5],variable.name = "ef",value.name = "expression")
ggplot(data = efmelt, aes(x=ef,y=expression))+
  geom_boxplot(aes(fill=subtype))+
  theme_bw()+
  theme(axis.text.x=element_text(vjust=1,size=10))+
  scale_fill_manual(values = c('L-hypoxia'='#ff7f00','H-hypoxia'='#1f78b4','M-hypoxia'='#B03060'))+
  annotate('text',x='GZMB',y=16,label = '**',size=5)+
  annotate('text',x='PRF1',y=16,label = 'ns',size=5)+
  annotate('text',x='TNF',y=16,label = '***',size=5)+
  annotate('text',x='IFNG',y=16,label = '*',size=5)+
  annotate('text',x='LAMP1',y=16,label = '*',size=5)+
  theme(axis.text.x = element_text(
    size = 10
  ))
