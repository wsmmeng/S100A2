##差异基因分析
load('hypoxia.Rdata')
##表达矩阵
rm(list=ls())
load('D:/泛癌免疫浸润(里面有处理突变信息和cluster分组免疫也很规范)/数据准备/CESC.Rdata')
CESCexpr <- CESCfinal[,-c(2:14)]
rownames(CESCexpr) <- CESCexpr[,1]
CESCexpr <- CESCexpr[,-1]
expr <- CESCexpr
##xena下载的数据是经过log的count值，所以要还原才可以进行差异分析
expr <- 2^expr-1
#并且还要取整数
expr <- floor(expr)
expr <- as.data.frame(t(expr)) ##列名是样品名，行名是基因名
v <- voom(expr, design, normalize="quantile")
##分组矩阵构建
sample$sample <- rownames(sample)
rownames(sample) <- c(1:296)
sample <- sample[,c(2,1)]
sample$group <- factor(sample$group,levels = c(1,2,3),labels = c("other",'cluster2','other'))
identical(sample$sample,colnames(expr))##看是否对应
##将cluster2视为一类，cluster1和cluster3视为一类

group <- sample[,2]
design <- model.matrix(~0+factor(group))
colnames(design)=levels(factor(group))
rownames(design) <- colnames(expr)

library(limma)
##对比矩阵
##cluster1-cluster2
cont.wt <- makeContrasts("cluster2-other",#举例
                         levels=design) 

fit <- lmFit(v, design)
fit2 <- contrasts.fit(fit, cont.wt) 
fit2 <- eBayes(fit2) 
tT=topTable(fit2, adjust="BH",sort.by="logFC",n=Inf)
tT = subset(tT, select=c("adj.P.Val","P.Value","logFC"))
colnames(tT)=c("FDR","P.Value","logFC")
nrDEG = na.omit(tT)
##第二步 提取差异表达的基因
deg <- nrDEG
##foldchange取2，变化为两倍，log2取1.5
logFC_t=1.5
deg$g=ifelse(deg$FDR>0.05,'stable',
             ifelse( deg$logFC > logFC_t,'UP',
                     ifelse( deg$logFC < -logFC_t,'DOWN','stable')))#增加一行g,为上调和下调的信息
save(deg,file = 'deg1c2and3.Rdata')


