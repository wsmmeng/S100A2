rm(list=ls())
load('MCP.Rdata')
subtype <- c(rep('L-hypoxia',112),rep('H-hypoxia',60),rep('M-hypoxia',124))
MCP <- rbind(MCPcountersubtype1,MCPcountersubtype2,MCPcountersubtype3)
MCPall <- cbind(subtype,MCP)
MCPall$subtype <- factor(MCPall$subtype,levels = c('L-hypoxia','H-hypoxia','M-hypoxia'))
##计算P值
pval <- c()
for(i in c(2:11)){
  p=summary(aov(MCPall[,i]~MCPall$subtype))[[1]][1,5]
  #存放p值
  pval=c(pval,p)
}
pval <- as.data.frame(pval)
rownames(pval) <- colnames(MCPall)[2:11]
#替换成*号
pval$mark <- as.factor(ifelse(pval$pval > 0.05,'ns',
                              ifelse(pval$pval> 0.01,'*',
                                     ifelse(pval$pval>0.001,'**','***'))
))
pvalMCP <- pval

library(reshape2)
MCPallmelt <- melt(MCPall,id.vars=c("subtype"),
             measure.vars = colnames(MCPall)[2:11],variable.name = "celltype",value.name = "expression")

ggplot(data = MCPallmelt, aes(x=celltype,y=expression,color=subtype))+
  geom_boxplot(aes(color=subtype))+
  theme(axis.text.x=element_text(vjust=1,size=10))+
  theme_classic()+
  scale_color_manual(values = c('L-hypoxia'='#ff7f00','H-hypoxia'='#1f78b4','M-hypoxia'='#B03060'))+
  annotate('text',x='T cells',y=8,label = '**',size=5)+
  annotate('text',x='CD8 T cells',y=8,label = '***',size=5)+
  annotate('text',x='Cytotoxic lymphocytes',y=8,label ='ns',size=5)+
  annotate('text',x='B lineage',y=8,label = '**',size=5)+
  annotate('text',x='NK cells',y=8,label = 'ns',size=5)+
  annotate('text',x='Monocytic lineage',y=8,label = '*',size=5)+
  annotate('text',x='Myeloid dendritic cells',y=8,label = '***',size=5)+
  annotate('text',x='Neutrophils',y=8,label = 'ns',size=5)+
  annotate('text',x='Endothelial cells',y=8,label = '**',size=5)+
  annotate('text',x='Fibroblasts',y=8,label = '***',size=5)+
  labs(title = 'MCPcounter',x='celltype',y='score')+
  theme(axis.text.x = element_text(
    angle = 45,
    hjust = 1,
    vjust = 1
  ))
