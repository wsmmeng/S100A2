rm(list=ls())
load('xcell.Rdata')
subtype <- c(rep('L-hypoxia',112),rep('H-hypoxia',60),rep('M-hypoxia',124))
xcell <- rbind(xCellsubtype1,xCellsubtype2,xCellsubtype3)
xcellall <- cbind(subtype,xcell)
celltype <- c("iDC","aDC","cDC","Th2 cells","Th1 cells","CD4+ Tem","CD8+ naive T-cells","Macrophages M2",
              "Monocytes","Tgd cells")
celltypeexpr <- xcellall[,c('subtype',celltype)]
celltypeexpr$subtype <- factor(celltypeexpr$subtype,levels = c('L-hypoxia','H-hypoxia','M-hypoxia'))
library(reshape2)
celltypemelt <- melt(celltypeexpr,id.vars=c("subtype"),
                   measure.vars = colnames(celltypeexpr)[2:11],variable.name = "celltype",value.name = "expression")

ggplot(data = celltypemelt, aes(x=celltype,y=expression,color=subtype))+
  geom_boxplot(aes(color=subtype))+
  theme(axis.text.x=element_text(vjust=1,size=10))+
  theme_classic()+
  scale_color_manual(values = c('L-hypoxia'='#ff7f00','H-hypoxia'='#1f71b4','M-hypoxia'='#B03060'))+
  annotate('text',x='iDC',y=1,label = '***',size=5)+
  annotate('text',x='aDC',y=1,label = '***',size=5)+
  annotate('text',x='cDC',y=1,label ='***',size=5)+
  annotate('text',x='Th2 cells',y=1,label = '***',size=5)+
  annotate('text',x='Th1 cells',y=1,label = '***',size=5)+
  annotate('text',x='CD4+ Tem',y=1,label = '***',size=5)+
  annotate('text',x='CD8+ naive T-cells',y=1,label = '***',size=5)+
  annotate('text',x='Macrophages M2',y=1,label = '***',size=5)+
  annotate('text',x='Monocytes',y=1,label = '***',size=5)+
  annotate('text',x='Tgd cells',y=1,label = '***',size=5)+
  labs(title = 'xCell',x='celltype',y='score')+
  theme(axis.text.x = element_text(
    angle = 45,
    hjust = 1,
    vjust = 1
  ))+
  ylim(0,1) 
