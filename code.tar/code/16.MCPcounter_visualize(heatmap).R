rm(list=ls())
load('MCP.Rdata')
subtype <- c(rep('L-hypoxia',112),rep('H-hypoxia',60),rep('M-hypoxia',124))
MCP <- rbind(MCPcountersubtype1,MCPcountersubtype2,MCPcountersubtype3)


MCPall <- cbind(subtype,MCP)

MCP <- as.data.frame(t(MCP))
MCPcellsc <- apply(MCP,1,scale)
rownames(MCPcellsc) <- colnames(MCP)
MCPcell <- as.data.frame(t(MCPcellsc))##归一化

##单独对细胞画热图
#确定颜色
library(ComplexHeatmap)
library(circlize)
col1 <- colorRamp2(
  c(-4,0,4),
  c('blue','white','red')
)
#确定注释
#列的注释
column_ha <- HeatmapAnnotation(
  
  subtype=subtype,
  col = list(
    subtype=c('L-hypoxia'='#ff7f00','H-hypoxia'='#1f78b4','M-hypoxia'='#B03060')
  ))
#行的注释
#进行批量T检验
pval <- c()
for(i in c(2:11)){
  p=summary(aov(MCPall[,i]~MCPall$subtype))[[1]][1,5]
  #存放p值
  pval=c(pval,p)
}
pval <- as.data.frame(pval)
rownames(pval) <- colnames(MCPall)[2:11]
#替换成*号
pval$mark <- as.factor(ifelse(pval$pval > 0.05,'ns',
                              ifelse(pval$pval> 0.01,'*',
                                     ifelse(pval$pval>0.001,'**','***'))
))
pvalMCP <- pval
#行的注释
ha <- rowAnnotation(
  p = anno_text(
    pval$mark,
    location = 0.3,
    gp=gpar(
      fontsize = 10
    )
  )
)

MCPpic <- Heatmap(MCPcell,name = 'MCPcounter',
                  #col = col1,
                  row_title = 'MCPcounter',
                  cluster_columns = F,
                  cluster_rows = T,
                  show_column_names = F,
                  row_names_gp = gpar(
                    fontsize = 13),
                  right_annotation = ha,
                  top_annotation = column_ha,
                  
)

draw(MCPpic)
save(MCPpic,file='MCPpic.Rdata')

